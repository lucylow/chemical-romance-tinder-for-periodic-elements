# CHEMICAL ROMANCE 💘🧪

**A swipe-right dating simulator for the periodic table.** Built with Expo + React Native + TypeScript for Replit.

## Run it
```bash
npm install
npx expo start --tunnel
```
In Replit, create a Node.js project, upload this folder, install dependencies and run `npm run start`. Use Expo Go on a device or an emulator.

## Gameplay
- Discover: swipe/like/pass element profiles.
- Matches: see discovered characters and their chemistry notes.
- Lab: assemble validated starter compounds (H₂O, CO₂, NaCl, NH₃, MgO).
- Memory: deterministic active recall cycles through element name, symbol, atomic number, family, period, and group; unavailable group values are excluded.
- Periodic World: browse all 118 entries by atomic number and family.
- Progress: local save, XP, streak, mastery and review queue.

## Science rules
Social chemistry is fictional. Chemical outcomes are independent and only shown when a curated educational scenario exists. An absent scenario means **not yet modelled**, not chemically impossible. The starter 118-row dataset includes names, symbols, atomic numbers, periods, groups where represented, blocks and broad families. The legacy `isDataVerified` boolean is not property-level provenance; only scientific facts with explicit status and a source reference are eligible to display as chemistry facts. Read `docs/SCIENCE_DATA_AUDIT.md` before extending the dataset.

## Architecture
- `src/data`: periodic table seed data and curated compounds.
- `src/engine`: deterministic swipe, match, formula and spaced-repetition logic.
- `src/store`: local persistence and game state.
- `src/screens`: mobile screens.
- `src/components`: reusable game UI.
- `tests`: core engine tests.

## Visual system
The interface uses a shared semantic palette, typography/spacing/radius/motion tokens, and a subtle molecular-gradient backdrop across screens. Discovery cards now pair real element records with an original native-view character portrait: palette and small silhouette details vary by element family and atomic number, so all 118 elements have an immediate lightweight illustration fallback. Fictional character lines are labelled separately; scientific properties appear only when they carry field-level provenance. The discovery card animates in and exits on PASS/LIKE; system reduced-motion preferences disable those transitions. See `docs/VISUAL_AUDIT.md` for the ranked visual audit and remaining visual work.

## Replit / Expo notes
Set the Run command to `npm run start -- --tunnel`. For web preview use `npm run web`. Discovery currently uses animated PASS/LIKE buttons rather than direct drag gestures. Optional original licensed image overrides can be added later; the native portrait fallback remains available. This project is a foundation, not a published production build. Validate scientific fields against authoritative references before classroom or production use.


## Gamification expansion (v2)

This expansion adds a local-first progression layer in `src/gamification/`:
- XP, player levels, titles, level progress, and daily XP safeguards
- Daily, weekly, story, collection, and mastery quests with claim-once rewards
- Badge catalogue, badge evaluation, and achievement gallery
- Streak tracking, calendar helpers, and purchasable streak freezes
- Lab coin wallet, cosmetic shop, profile themes, card frames, stickers, and titles
- Collection sets, family boss rounds, seasonal events, weekly summaries, and player stats
- A separate `GamificationProvider` backed by AsyncStorage
- New routes: `/gamification`, `/quests`, `/badges`, and `/shop`

### Gamification routes
Open the routes from Expo Router:
- `/gamification` — player level and stats
- `/quests` — quest board
- `/badges` — achievement gallery
- `/shop` — cosmetic shop

### Integration note
The gamification provider is a separate local save from the original discovery `GameProvider`. Events are now recorded at their source: each discovery swipe records `element_discovered`, likes additionally record `element_liked`, memory answers record `quiz_correct` or `quiz_wrong`, and a valid lab result records `formula_built`. A formula's scenario reward is granted once, not repeatedly by checking the same build. The fictional match preview is not counted as a mutual match.

The original Progress tab and Gamification dashboard therefore show different progression ledgers; do not interpret their XP totals as one combined balance. Add future `useGamification().record(...)` calls only at the action handler, never in a render effect.

### Gamification test
Install reproducibly with `npm install` (the lockfile is included). Run `npm run typecheck`, `npm test -- --runInBand`, and `npx expo export --platform web` to check types, unit tests, and the Expo web bundle.
