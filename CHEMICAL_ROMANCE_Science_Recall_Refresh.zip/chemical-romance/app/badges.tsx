export {BadgeGalleryScreen as default} from "../src/gamification/screens/BadgeGalleryScreen";
