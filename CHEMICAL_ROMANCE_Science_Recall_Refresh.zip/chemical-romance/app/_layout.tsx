import React from "react";
import {Stack} from "expo-router";
import {GestureHandlerRootView} from "react-native-gesture-handler";
import {GameProvider} from "../src/store/GameContext";
import {GamificationProvider} from "../src/gamification/GamificationContext";
export default function RootLayout(){return <GestureHandlerRootView style={{flex:1}}><GameProvider><GamificationProvider><Stack screenOptions={{headerShown:false}}><Stack.Screen name="index"/><Stack.Screen name="gamification"/><Stack.Screen name="quests"/><Stack.Screen name="badges"/><Stack.Screen name="shop"/></Stack></GamificationProvider></GameProvider></GestureHandlerRootView>}
