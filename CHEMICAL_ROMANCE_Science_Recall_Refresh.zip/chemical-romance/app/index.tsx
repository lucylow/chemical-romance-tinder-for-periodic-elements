import React, { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useRouter } from "expo-router";
import { DiscoverScreen } from "../src/screens/DiscoverScreen";
import { MatchesScreen } from "../src/screens/MatchesScreen";
import { MemoryScreen } from "../src/screens/MemoryScreen";
import { LabScreen } from "../src/screens/LabScreen";
import { PeriodicScreen } from "../src/screens/PeriodicScreen";
import { ProgressScreen } from "../src/screens/ProgressScreen";
import { colors } from "../src/theme/colors";

const tabs = [
  ["Discover", "💘"],
  ["Matches", "💞"],
  ["Memory", "🧠"],
  ["Lab", "⚗️"],
  ["World", "🌎"],
  ["Progress", "✨"],
] as const;
type Tab = (typeof tabs)[number][0];

const screens: Record<Tab, React.ComponentType> = {
  Discover: DiscoverScreen,
  Matches: MatchesScreen,
  Memory: MemoryScreen,
  Lab: LabScreen,
  World: PeriodicScreen,
  Progress: ProgressScreen,
};

export default function Home() {
  const [tab, setTab] = useState<Tab>("Discover");
  const router = useRouter();
  const CurrentScreen = screens[tab];

  return (
    <View style={styles.root}>
      <StatusBar style="light" />
      <View style={styles.brand}>
        <View>
          <Text style={styles.logo}>
            CHEMICAL <Text style={styles.logoAccent}>ROMANCE</Text>
          </Text>
          <Text style={styles.tag}>SWIPE RIGHT FOR CHEMISTRY</Text>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Open rewards, level, and streak"
          onPress={() => router.push("/gamification")}
          style={styles.rewardsButton}
        >
          <Text style={styles.rewardsIcon}>✦</Text>
          <Text style={styles.rewardsLabel}>Rewards</Text>
        </Pressable>
      </View>

      <View style={styles.content}>
        <CurrentScreen />
      </View>

      <View style={styles.nav}>
        {tabs.map(([name, emoji]) => {
          const selected = tab === name;
          return (
            <Pressable
              key={name}
              accessibilityRole="button"
              accessibilityLabel={`${name} tab`}
              accessibilityState={{ selected }}
              onPress={() => setTab(name)}
              style={[styles.item, selected && styles.active]}
            >
              <Text style={styles.emoji}>{emoji}</Text>
              <Text style={[styles.label, selected && styles.activeLabel]}>{name}</Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.bg },
  brand: {
    paddingTop: 12,
    paddingBottom: 8,
    paddingHorizontal: 18,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: colors.bg,
  },
  logo: { fontSize: 19, fontWeight: "900", letterSpacing: 1.3, color: colors.text },
  logoAccent: { color: colors.pink },
  tag: { fontSize: 8, letterSpacing: 2, color: colors.muted, marginTop: 3 },
  rewardsButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 11,
    paddingVertical: 8,
    borderRadius: 14,
    backgroundColor: colors.surface2,
    borderWidth: 1,
    borderColor: colors.border,
  },
  rewardsIcon: { color: colors.gold, fontSize: 16, fontWeight: "900" },
  rewardsLabel: { color: colors.text, fontSize: 11, fontWeight: "800" },
  content: { flex: 1 },
  nav: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingTop: 9,
    paddingBottom: 16,
    backgroundColor: colors.surface,
    borderTopWidth: 1,
    borderColor: colors.border,
  },
  item: { alignItems: "center", paddingHorizontal: 6, paddingVertical: 5, borderRadius: 12, minWidth: 48 },
  active: { backgroundColor: colors.surface2 },
  emoji: { fontSize: 18 },
  label: { fontSize: 9, color: colors.muted, marginTop: 2, fontWeight: "700" },
  activeLabel: { color: colors.pink },
});
