export {GamificationScreen as default} from "../src/gamification/screens/GamificationScreen";
