# Code Page 009 — Mutual match semantics

This implementation note defines one bounded engineering responsibility in CHEMICAL ROMANCE. Keep the module deterministic, testable and separate from character flavour text.

## Contract
- Inputs must be explicit and typed.
- Invalid or missing data must return a safe result rather than fabricate chemistry.
- User progress must remain local in the starter build.
- UI components should render state; domain engines should own rules.

## Implementation checklist
1. Define the TypeScript interface for the feature.
2. Implement the smallest pure function that owns the rule.
3. Add a unit test for the normal case.
4. Add a test for missing, invalid or boundary input.
5. Connect the result to the relevant screen.
6. Add an accessible label and a useful empty state.
7. Document whether the feature is production-ready or a starter placeholder.

## Acceptance criteria
The feature works offline, does not create unsupported scientific claims, preserves the canonical element schema and can be tested without rendering the entire application.

## Relevant modules
See `src/engine`, `src/screens`, `src/store` and `tests`. Extend existing modules instead of introducing a second competing state or chemistry architecture.
