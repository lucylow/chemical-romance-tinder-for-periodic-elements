# Replit setup

1. Create a Node.js Replit.
2. Upload the extracted `chemical-romance` project contents.
3. Install dependencies with `npm install`.
4. Run `npm run start -- --tunnel`.
5. Scan the Expo QR code with Expo Go, or open the web preview with `npm run web`.

If Replit's web preview is the primary target, test `npm run web`. Native haptics, speech and device-specific interactions should be added only after validating the mobile build.
