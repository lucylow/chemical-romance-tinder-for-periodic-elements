# Replit Agent continuation prompt

Continue this project without replacing its architecture. Preserve Expo Router, TypeScript, the canonical `ElementCharacter` schema, local-first persistence and deterministic chemistry validation.

Priority tasks:
1. Finish swipe card gesture support with `react-native-gesture-handler` and Reanimated, including reduced-motion fallback.
2. Add profile detail modal and relationship story screen.
3. Add blank periodic-table reconstruction game with actual group/period coordinates and a clear f-block inset.
4. Add six independent mastery skills per element and a review queue screen.
5. Expand the curated compound dataset only with reviewed references and balanced stoichiometry.
6. Add original character art placeholders and an art pipeline.
7. Add tests for chemistry formulas, memory scheduling, persistence migration, and dataset completeness.
8. Keep AI dialogue optional; never let generated text create chemical facts.
9. Add accessibility labels, dynamic type, localization and error states.
10. Run TypeScript checks and native iOS/Android smoke tests after each feature.

Do not claim all 118 biographies, advanced chemistry fields, AI chat, cloud sync or multiplayer are production complete merely because the identity dataset contains 118 rows.
