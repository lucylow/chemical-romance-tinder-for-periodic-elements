# Gamification implementation 095: Activity integrity

## Purpose
Implement **activity integrity** as a learning-first progression mechanic in CHEMICAL ROMANCE.

## Product behaviour
- Reward meaningful chemistry learning rather than endless tapping.
- Never penalize a player for taking a break or answering incorrectly.
- Keep rewards cosmetic or celebratory; do not sell chemistry knowledge or quiz advantages.
- Preserve local-first play and allow the game to function offline.

## Engineering contract
- Keep domain rules in `src/gamification/` rather than inside React components.
- Use typed inputs and outputs; validate user-generated or persisted data.
- Make reward claims idempotent so a player cannot claim the same reward twice.
- Keep date boundaries consistent with the device-local calendar unless the feature explicitly says otherwise.
- Add a unit test for the success path, failure path, boundary values, and repeated invocation.

## Acceptance criteria
1. The mechanic produces deterministic results for the same state and inputs.
2. A repeated claim or purchase cannot duplicate rewards.
3. Progress survives app restarts through the gamification persistence provider.
4. Screen-reader labels describe progress and rewards in plain language.
5. The mechanic does not create a pay-to-win advantage.

## Relevant implementation
See `src/gamification/activity_integrity.ts` where available, plus the matching screen or component.
