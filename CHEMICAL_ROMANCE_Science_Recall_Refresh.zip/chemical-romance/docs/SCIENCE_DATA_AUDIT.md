# CHEMICAL ROMANCE — Scientific Data Audit

Audit performed on the starter `src/data/elements.json` records using `auditElementDataset()` and `validateElementDataset()`. This is a structural audit only; it does not independently verify chemistry values against external references.

## Current coverage

| Area | Result |
|---|---:|
| Element records | 118 / 118 |
| Unique atomic numbers | 118 / 118 |
| Unique names and symbols | 118 / 118 |
| Present period and block fields | 118 / 118 |
| Records with `group: null` | 26 / 118; permitted for the current starter representation, but group conventions still need editorial review |
| Legacy `isDataVerified: true` flag | 24 records; not a citation and not a per-property verification status |
| Source-linked scientific facts | 0 |
| `realWorldUses` entries | 0 across the dataset |
| `signatureFact` identical to the fictional `tagline` | 24 records |

These fields are absent for all 118 records: atomic weight, electron configuration, phase at room conditions, density, melting and boiling points, electronegativity, ionization energy, discovery metadata, and isotope records. No source URL, retrieval date, measurement condition, or uncertainty accompanies a property.

## Changes made

- Added `ScientificFact` and provenance types with explicit statuses for measured, evaluated, calculated, predicted, estimated, not-established, not-applicable, and unverified values.
- Added a trust-boundary helper: a fact is displayable only if it has a label/value, a non-unverified status, a source name, an HTTP(S) reference, and a retrieval date.
- Changed the discovery card so fictional taglines are labelled as character dialogue and never shown as chemistry facts. Since no property-level sources exist in the starter JSON, the card now says so plainly.
- Strengthened structural checks for the full 118-record identity set, symbol/name uniqueness, group range, period range, and block values.
- Added deterministic memory questions for symbol, name, atomic number, family, period, and group recall. Group questions exclude records whose group is null; answer choices are unique and reproducible. Correct-answer feedback now matches the actual +5 study XP award.

## Recommended next data phase

Do not fill the missing fields with model-generated guesses. Select one property group at a time, adopt an authoritative reference and its licensing/attribution rules, import the data with field-level provenance, then review exceptions such as standard atomic-weight intervals and predicted superheavy-element properties. Keep simplified teaching text, measured values, predictions, and fictional character copy in separate fields.
