# Open CHEMICAL ROMANCE in Expo Go

Scan the [current Expo Go QR code](./expo-go-qr.png) with the Expo Go app (Android) or the iOS Camera app. The link encoded by this QR is:

```text
exp://ova1qe8-anonymous-8081.exp.direct
```

This is a temporary development tunnel, not a production install link. It works only while the Expo server for this session remains running; after the session ends, start a fresh tunnel with `npx expo start --tunnel` and replace the QR with the newly printed one.
