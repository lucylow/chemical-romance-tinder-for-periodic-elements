# Art direction — CHEMICAL ROMANCE
- Cute anime mascot energy, expressive but not childish.
- Distinct silhouettes, palettes and motifs derived from element families.
- Pastel pink, lavender, deep plum and cyan on a dark night-sky interface.
- Collectible profile cards with oversized symbols and atomic-number labels.
- No generic recoloured clones: visual identity should connect to each element's real properties.
- Design original assets; no copied franchise characters or logos.
