# CHEMICAL ROMANCE — Game Design Blueprint

## Core fantasy
The periodic table is a dating app. The player is the matchmaker at a chaotic science academy. Every element has a character identity based on real properties, but social drama is explicitly fictional.

## Core loop
1. Meet an element profile.
2. Read its symbol, atomic number, family and memory hook.
3. Like or pass; likes populate the collection.
4. Answer a retrieval question about the element.
5. Use the Chemistry Lab to build a curated formula.
6. Revisit due facts to improve long-term recall.

## Two compatibility systems
- Social score: playful and fictional. It must never be described as a chemical measurement.
- Chemistry status: only a curated database lookup. The UI distinguishes known examples from unmodelled pairs.

## Progression
- Encounter: visual recognition.
- Recall: hide name or symbol and ask the player to retrieve it.
- Reinforce: schedule the skill for review.
- Master: require repeated independent recall across several skill dimensions. A single correct answer never grants mastery.

## First release scope
- 118 identity cards with atomic number, symbol, name, period, broad family, block and group when represented.
- Six mobile sections: Discover, Matches, Memory, Lab, World, Progress.
- Local persistence.
- Starter compound notebook.
- Quiz feedback and XP.

## Deferred systems
AI chats, online multiplayer, teacher dashboards, cloud accounts, monetization, voice acting, character art and full molecular visualization are intentionally not presented as implemented.
