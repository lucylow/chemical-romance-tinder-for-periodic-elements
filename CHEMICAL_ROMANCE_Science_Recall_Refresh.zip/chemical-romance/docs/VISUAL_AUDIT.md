# CHEMICAL ROMANCE — Visual Audit

This audit covers the supplied Expo project as it existed before this visual pass. Priorities are ranked by user impact and risk to the core discovery loop. The current iteration improves the shared visual foundation and the first-impression discovery path; it does not claim that every screen in the attached 100-page brief is complete.

| Priority | Finding | Impact | This iteration | Remaining work |
|---|---|---|---|---|
| P0 | No character artwork existed; the discovery card used a plain element-symbol orb. | Discovery lacked a collectible-game identity. | Added `CharacterPortrait`, an original native-view illustrated fallback with family palettes and atomic-number-driven variations, used on the primary card. | Commission or generate individual licensed portraits and expressions, then add optional per-element overrides. |
| P0 | Chemistry facts and fictional personality cues shared an undifferentiated card layout. | Readers could mistake starter data or fiction for verified science. | Character lines are explicitly labelled fictional; the card renders a property only when it has field-level status and source provenance. The legacy boolean is not treated as verification. | Review scientific fields against authoritative sources and link citations in the product. |
| P1 | The app used a flat background and scattered one-off style values. | Screens felt disconnected and visually generic. | Added semantic palette, typography, spacing, radius, layout and motion tokens; applied a subtle molecular-gradient backdrop through the common screen wrapper. | Migrate remaining individual screen styles onto tokens and define a complementary light theme if required. |
| P1 | Discovery had no transition or visual state feedback beyond button presses. | The main interaction felt static. | Added a spring card reveal, button-triggered slide/tilt/fade with LIKE/PASS stamps, duplicate-tap protection, and reduced-motion handling. | Add direct pan gestures, haptics, a bespoke match scene, and device-level gesture testing. |
| P1 | Shared buttons had inconsistent contrast and incomplete accessibility feedback. | Actions were less legible and their states less explicit. | Standardized 48-point minimum targets, contrast by variant, accessibility labels/state, pressed/disabled styles, and optional loading indication. | Audit individual touch targets and screen-reader order across every screen on iOS and Android. |
| P2 | Collection, periodic-table, quest, badge and shop surfaces remain relatively information-dense and use simple grid/card treatments. | The whole app is not yet at the same polish level as the discovery card. | The shared background and palette now apply across screens. | Redesign each screen in a follow-up pass, including family-aware collection art, more informative empty states, cosmetic previews, and a true periodic-table layout. |
| P2 | Match/quest/badge/purchase moments lack dedicated layered celebrations. | Progression rewards have limited emotional payoff. | Kept all existing action and reward behavior intact. | Add reusable reward/match overlays that reflect confirmed state changes, with reduced-motion alternatives and tests. |
| P3 | There is no finished app-icon, splash, world-map, or 118-piece hand-illustrated asset set. | Brand identity and long-term content scope remain incomplete. | Added an asset manifest and documented the lightweight portrait fallback/override convention. | Produce optimized licensed art assets, configure platform icons/splash, and validate the complete asset library. |

## Art direction established

The visual direction is a dark romantic laboratory: midnight plum surfaces, pink as the social/action accent, violet for progression, cyan for scientific information, mint for success, and gold for rewards. The native portrait is a stylized non-photorealistic element character, not a scientific diagram. Family colors and element-derived variations make the placeholder system distinct without claiming full custom character artwork.

## Validation

- Strict TypeScript check: pass.
- Jest: 26 tests pass after the science-data and active-recall update.
- Expo web export: pass after the visual changes.
- Expo web mobile-viewport screenshots: Discover, Memory Academy, and Helium's character personality card captured and visually reviewed at 390 × 844 in `docs/screenshots/discover-screen.png`, `docs/screenshots/memory-screen.png`, and `docs/screenshots/helium-personality.png`.
- Native iOS/Android screenshot and accessibility-device review: not performed in this sandbox.
