# Element content authoring template

For each element, an editor should approve:
- Display name
- Symbol
- Atomic number
- Group, period and block
- Broad family and category
- Electron configuration
- Common oxidation states (where appropriate)
- State at 25 °C and standard conditions definition
- Atomic weight / isotope caveat
- Personality title
- Memory hook
- One concise scientific fact
- Real-world uses with source references
- Character dialogue
- Image brief and licensing status
- Learning tags
- Reviewer and last-verified date

The seed data intentionally does not fabricate advanced values for all 118 elements.
