# Science content policy

1. Element identity is the canonical anchor: atomic number, symbol and name.
2. Group/period and block placement must be reviewed for f-block display conventions and edge cases.
3. Family labels are simplified teaching categories, not exhaustive descriptions of chemistry.
4. A social compatibility score is a game mechanic, not a scientific metric.
5. Chemical outcomes are only displayed from curated educational records.
6. No record means “not modelled”, not “cannot react”.
7. Ionic compounds require charge-balanced stoichiometry; formulas are not always 1:1.
8. Ionic solids such as NaCl are formula units in extended lattices, not discrete molecules.
9. Covalent molecular shape and bonding context should be included as lessons expand.
10. Hazardous substances and reactions are not simulated as real-world instructions.
11. AI, if introduced, may produce dialogue but cannot author authoritative chemistry claims without validation.
12. Every scientific claim must have a source, reviewer and version before production release.
