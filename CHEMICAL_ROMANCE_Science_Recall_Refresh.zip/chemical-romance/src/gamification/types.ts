export type QuestKind = "daily" | "weekly" | "story" | "collection" | "mastery" | "social";
export type RewardKind = "xp" | "coins" | "badge" | "title" | "theme" | "sticker";
export type Rarity = "common" | "uncommon" | "rare" | "epic" | "legendary";
export type ActivityKind =
  | "element_discovered" | "element_liked" | "element_matched"
  | "quiz_correct" | "quiz_wrong" | "formula_built" | "lesson_completed"
  | "daily_challenge_completed" | "review_completed" | "streak_day"
  | "collection_completed" | "boss_defeated" | "perfect_round";

export interface Reward { kind: RewardKind; amount?: number; id?: string; label: string; }
export interface QuestDefinition {
  id: string; title: string; description: string; kind: QuestKind;
  target: number; activity: ActivityKind; reward: Reward[]; icon: string;
  rarity?: Rarity; prerequisites?: string[];
}
export interface QuestProgress { questId: string; value: number; completed: boolean; claimed: boolean; updatedAt: string; }
export interface BadgeDefinition { id: string; name: string; description: string; icon: string; rarity: Rarity; rule: string; }
export interface PlayerBadge { badgeId: string; unlockedAt: string; }
export interface GameActivity { id: string; kind: ActivityKind; amount: number; at: string; metadata?: Record<string, string | number | boolean>; }
export interface LevelInfo { level: number; title: string; minXp: number; nextLevelXp: number; progress: number; }
export interface StreakInfo { current: number; best: number; freezes: number; lastActiveDate: string | null; }
export interface CurrencyWallet { coins: number; lifetimeEarned: number; lifetimeSpent: number; }
export interface CosmeticItem { id: string; name: string; description: string; price: number; rarity: Rarity; category: "card-frame" | "profile-theme" | "sticker" | "title"; preview: string; }
export interface GamificationState {
  schemaVersion: number; totalXp: number; wallet: CurrencyWallet; streak: StreakInfo;
  quests: Record<string, QuestProgress>; badges: PlayerBadge[]; inventory: string[];
  equipped: Record<string, string | null>; activity: GameActivity[];
  dailyClaimedAt: string | null; weeklyClaimedAt: string | null;
  lifetime: Record<string, number>; updatedAt: string;
}
export interface ActivityResult { state: GamificationState; xpAwarded: number; coinsAwarded: number; unlockedBadges: BadgeDefinition[]; completedQuests: QuestDefinition[]; }
