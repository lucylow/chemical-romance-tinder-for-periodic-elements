import {createGamificationState} from "./defaultState";
export function resetGamification(){return createGamificationState();}
