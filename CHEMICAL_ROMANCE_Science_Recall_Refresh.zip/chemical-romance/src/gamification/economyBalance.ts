import type {CosmeticItem} from "./types";
export function economyAudit(items:CosmeticItem[]):string[] {
 const errors:string[]=[];for(const item of items){if(item.price<0)errors.push(`${item.id}: negative price`);if(!item.id)errors.push("Cosmetic missing id");}
 const prices=items.map(i=>i.price).filter(n=>n>0);
 if(prices.length&&Math.min(...prices)<10)errors.push("Check low-price inflation.");
 return errors;
}
