export const BALANCE = {dailyQuestCount:3,weeklyQuestCount:2,streakFreezeMax:2,coinRewardPerLevel:3,comboWindowMs:45000,maxComboMultiplier:3,reviewXp:10,discoveryXp:8};
export function clampReward(value:number,min=0,max=1000):number{return Math.max(min,Math.min(max,Math.floor(value)));}
