export function questStatusCopy(done:boolean,claimed:boolean):string {
 if(claimed)return "Reward collected";
 if(done)return "Ready to claim";
 return "Keep going — you're making progress";
}
export function questProgressCopy(value:number,target:number):string{return `${Math.min(value,target)} / ${target}`;}
