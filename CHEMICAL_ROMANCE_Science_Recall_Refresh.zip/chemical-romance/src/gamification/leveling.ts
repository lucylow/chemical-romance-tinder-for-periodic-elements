import { LEVEL_TITLES, XP_PER_LEVEL } from "./constants";
import type { LevelInfo } from "./types";
export function xpRequiredForLevel(level: number): number {
  const safe = Math.max(1, Math.floor(level));
  return Math.floor(XP_PER_LEVEL * Math.pow(safe - 1, 1.35));
}
export function levelFromXp(totalXp: number): LevelInfo {
  const xp = Math.max(0, Math.floor(totalXp));
  let level = 1;
  while (level < 100 && xp >= xpRequiredForLevel(level + 1)) level++;
  const minXp = xpRequiredForLevel(level), nextLevelXp = xpRequiredForLevel(level + 1);
  return { level, title: LEVEL_TITLES[Math.min(level - 1, LEVEL_TITLES.length - 1)],
    minXp, nextLevelXp, progress: Math.max(0, Math.min(1, (xp - minXp) / Math.max(1, nextLevelXp - minXp))) };
}
export function xpToNextLevel(totalXp: number): number { const l = levelFromXp(totalXp); return Math.max(0, l.nextLevelXp - totalXp); }
