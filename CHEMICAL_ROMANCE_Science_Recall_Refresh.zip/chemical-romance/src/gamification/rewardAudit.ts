import {QUEST_CATALOG} from "./questCatalog";
export function auditRewardCatalog():string[] {
 const errors:string[]=[];for(const q of QUEST_CATALOG){for(const r of q.reward){if((r.amount??0)<0)errors.push(`${q.id} has a negative reward`);}}
 return errors;
}
