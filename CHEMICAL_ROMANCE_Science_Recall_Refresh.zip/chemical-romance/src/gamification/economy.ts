import type { CosmeticItem, GamificationState } from "./types";
export function canPurchase(state:GamificationState,item:CosmeticItem):boolean{return state.wallet.coins>=item.price&&!state.inventory.includes(item.id);}
export function purchase(state:GamificationState,item:CosmeticItem):GamificationState {
  if(!canPurchase(state,item))return state;
  return {...state,wallet:{...state.wallet,coins:state.wallet.coins-item.price,lifetimeSpent:state.wallet.lifetimeSpent+item.price},inventory:[...state.inventory,item.id],updatedAt:new Date().toISOString()};
}
export function equip(state:GamificationState,item:CosmeticItem):GamificationState {
  if(!state.inventory.includes(item.id))return state;
  return {...state,equipped:{...state.equipped,[item.category]:item.id}};
}
export function grantCoins(state:GamificationState,amount:number):GamificationState {
  if(!Number.isFinite(amount)||amount<=0)return state;
  return {...state,wallet:{...state.wallet,coins:state.wallet.coins+Math.floor(amount),lifetimeEarned:state.wallet.lifetimeEarned+Math.floor(amount)}};
}
