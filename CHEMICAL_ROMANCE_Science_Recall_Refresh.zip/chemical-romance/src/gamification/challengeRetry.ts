export interface RetryState {attempts:number;bestScore:number;lastAttemptAt:string|null;}
export function recordRetry(s:RetryState,score:number):RetryState{return {attempts:s.attempts+1,bestScore:Math.max(s.bestScore,score),lastAttemptAt:new Date().toISOString()};}
