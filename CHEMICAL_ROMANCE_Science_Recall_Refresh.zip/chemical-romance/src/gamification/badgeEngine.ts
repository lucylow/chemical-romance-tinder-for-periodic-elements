import { BADGE_CATALOG } from "./badgeCatalog";
import type { BadgeDefinition, GamificationState } from "./types";
export interface BadgeStats { discoveries:number; matches:number; correct:number; perfectRounds:number; formulas:number; bestStreak:number; dailyChallenges:number; cosmetics:number; coinsEarned:number; storyQuests:number; families:number; }
const checks: Record<string, (s:BadgeStats)=>boolean> = {
  first_crush:s=>s.discoveries>=1, ten_faces:s=>s.discoveries>=10, fifty_faces:s=>s.discoveries>=50,
  full_table:s=>s.discoveries>=118, first_match:s=>s.matches>=1, ten_matches:s=>s.matches>=10,
  quiz_starter:s=>s.correct>=1, quiz_ace:s=>s.correct>=100, perfect_ten:s=>s.perfectRounds>=10,
  lab_apprentice:s=>s.formulas>=1, lab_master:s=>s.formulas>=50, week_warrior:s=>s.bestStreak>=7,
  month_mind:s=>s.bestStreak>=30, daily_devotee:s=>s.dailyChallenges>=10, collector:s=>s.cosmetics>=5,
  coin_saver:s=>s.coinsEarned>=250, story_reader:s=>s.storyQuests>=5, family_friend:s=>s.families>=10
};
export function evaluateNewBadges(state:GamificationState, stats:BadgeStats):{state:GamificationState;unlocked:BadgeDefinition[]} {
  const owned = new Set(state.badges.map(b=>b.badgeId));
  const unlocked = BADGE_CATALOG.filter(b=>!owned.has(b.id) && (checks[b.id]?.(stats) ?? false));
  if (!unlocked.length) return {state,unlocked};
  const now = new Date().toISOString();
  return {state:{...state,badges:[...state.badges,...unlocked.map(b=>({badgeId:b.id,unlockedAt:now}))]},unlocked};
}
