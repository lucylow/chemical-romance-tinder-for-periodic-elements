import type {GamificationState} from "./types";
import type {CollectionSet} from "./collectionSets";
import {collectionComplete} from "./collectionSets";
export function claimCollection(state:GamificationState,set:CollectionSet,discovered:number[]):GamificationState {
 const key=`collection:${set.id}`;if(!collectionComplete(set,discovered)||(state.lifetime[key]??0)>0)return state;
 return {...state,totalXp:state.totalXp+set.rewardXp,wallet:{...state.wallet,coins:state.wallet.coins+set.rewardCoins,lifetimeEarned:state.wallet.lifetimeEarned+set.rewardCoins},lifetime:{...state.lifetime,[key]:1}};
}
