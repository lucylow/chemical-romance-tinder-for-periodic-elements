export function levelCoinReward(level:number):number{return Math.max(5,Math.floor(level*3));}
export function milestoneLevel(level:number):boolean{return level>1&&level%5===0;}
