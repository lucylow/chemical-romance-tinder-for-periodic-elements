export interface Goal {id:string;label:string;target:number;metric:string;}
export const PLAYER_GOALS:Goal[]=[
{id:"discover-25",label:"Meet 25 elements",target:25,metric:"element_discovered"},
{id:"recall-50",label:"Recall 50 facts",target:50,metric:"quiz_correct"},
{id:"build-10",label:"Build 10 compounds",target:10,metric:"formula_built"},
{id:"streak-7",label:"Keep a seven-day streak",target:7,metric:"streak_best"}
];
