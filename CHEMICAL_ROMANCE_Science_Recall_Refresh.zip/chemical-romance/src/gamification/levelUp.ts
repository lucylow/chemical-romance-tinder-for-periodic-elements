import {levelFromXp} from "./leveling";
export function didLevelUp(before:number,after:number):boolean{return levelFromXp(after).level>levelFromXp(before).level;}
export function levelsGained(before:number,after:number):number{return Math.max(0,levelFromXp(after).level-levelFromXp(before).level);}
