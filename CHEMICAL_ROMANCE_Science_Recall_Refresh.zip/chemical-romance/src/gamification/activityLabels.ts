import type {ActivityKind} from "./types";
export const ACTIVITY_LABELS:Record<ActivityKind,string>={
element_discovered:"Discovered an element",element_liked:"Liked an element",element_matched:"Made a match",
quiz_correct:"Correct recall",quiz_wrong:"Practice attempt",formula_built:"Built a compound",
lesson_completed:"Completed a lesson",daily_challenge_completed:"Completed daily challenge",
review_completed:"Finished a memory review",streak_day:"Kept a learning streak",
collection_completed:"Completed a collection",boss_defeated:"Defeated a family boss",perfect_round:"Perfect round"
};
