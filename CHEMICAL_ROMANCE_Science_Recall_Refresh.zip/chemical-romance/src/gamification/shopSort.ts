import type {CosmeticItem} from "./types";
export function sortCosmetics(items:CosmeticItem[],sort:"price-low"|"price-high"|"rarity"="price-low"):CosmeticItem[] {
 const rarity={common:1,uncommon:2,rare:3,epic:4,legendary:5};
 return [...items].sort((a,b)=>sort==="price-high"?b.price-a.price:sort==="rarity"?rarity[b.rarity]-rarity[a.rarity]:a.price-b.price);
}
