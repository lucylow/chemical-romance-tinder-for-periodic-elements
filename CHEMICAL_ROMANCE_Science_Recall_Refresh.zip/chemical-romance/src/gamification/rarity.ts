import type {Rarity} from "./types";
export const RARITY_LABEL:Record<Rarity,string>={common:"Common",uncommon:"Uncommon",rare:"Rare",epic:"Epic",legendary:"Legendary"};
export const RARITY_ORDER:Record<Rarity,number>={common:1,uncommon:2,rare:3,epic:4,legendary:5};
export function compareRarity(a:Rarity,b:Rarity):number{return RARITY_ORDER[b]-RARITY_ORDER[a];}
