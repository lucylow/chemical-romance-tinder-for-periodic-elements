import type { GamificationState } from "./types";
import { challengeForDate, isChallengeComplete } from "./dailyChallengeEngine";
import { localDateKey } from "./date";
export function claimDailyReward(state:GamificationState,date=new Date()):{state:GamificationState;claimed:boolean;xp:number;coins:number} {
  const key=localDateKey(date), challenge=challengeForDate(date);
  if(state.dailyClaimedAt===key||!isChallengeComplete(state,date))return {state,claimed:false,xp:0,coins:0};
  const next={...state,totalXp:state.totalXp+challenge.rewardXp,wallet:{...state.wallet,coins:state.wallet.coins+challenge.rewardCoins,lifetimeEarned:state.wallet.lifetimeEarned+challenge.rewardCoins},dailyClaimedAt:key};
  return {state:next,claimed:true,xp:challenge.rewardXp,coins:challenge.rewardCoins};
}
