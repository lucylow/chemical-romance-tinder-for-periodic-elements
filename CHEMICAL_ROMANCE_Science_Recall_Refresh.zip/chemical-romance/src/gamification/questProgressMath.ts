export function progressRatio(value:number,target:number):number{return target<=0?0:Math.max(0,Math.min(1,value/target));}
export function progressPercent(value:number,target:number):number{return Math.round(progressRatio(value,target)*100);}
