export interface ComboState { count:number; multiplier:number; lastActionAt:number|null; }
export function nextCombo(s:ComboState,now=Date.now()):ComboState {
 const alive=s.lastActionAt!==null&&now-s.lastActionAt<=45000;
 const count=alive?s.count+1:1;
 return {count,multiplier:count>=10?3:count>=5?2:count>=3?1.5:1,lastActionAt:now};
}
export function comboBonus(base:number,s:ComboState):number{return Math.floor(base*Math.max(1,s.multiplier))-base;}
