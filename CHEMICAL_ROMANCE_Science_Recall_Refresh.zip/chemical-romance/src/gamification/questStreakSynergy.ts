export function questStreakBonus(coins:number,streak:number):number {
 const bonus=streak>=14?0.2:streak>=7?0.1:0;return Math.floor(coins*bonus);
}
