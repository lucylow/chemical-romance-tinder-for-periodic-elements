export interface EventDay {date:string;label:string;bonus:string;}
export function eventCalendar(days=14,start=new Date()):EventDay[] {
 return Array.from({length:days},(_,i)=>{const d=new Date(start);d.setDate(d.getDate()+i);return {date:d.toISOString().slice(0,10),label:i===0?"Today":d.toLocaleDateString(undefined,{weekday:"short"}),bonus:i%7===6?"Weekly reward":"Daily chemistry"};});
}
