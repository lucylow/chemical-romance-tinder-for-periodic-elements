export interface DailyGoal {label:string;target:number;metric:string;rewardXp:number;}
export const DAILY_GOALS:DailyGoal[]=[
{label:"Discover 3 elements",target:3,metric:"element_discovered",rewardXp:15},
{label:"Answer 5 questions",target:5,metric:"quiz_correct",rewardXp:20},
{label:"Complete 2 reviews",target:2,metric:"review_completed",rewardXp:15}
];
