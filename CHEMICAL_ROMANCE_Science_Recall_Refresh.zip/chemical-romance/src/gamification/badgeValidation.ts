import type {BadgeDefinition} from "./types";
export function validateBadges(items:BadgeDefinition[]):string[] {
 const ids=new Set<string>(),errors:string[]=[];for(const b of items){if(ids.has(b.id))errors.push(`Duplicate badge id: ${b.id}`);ids.add(b.id);if(!b.description)errors.push(`${b.id} has no description`);}return errors;
}
