export function eventReward(base:number,active:boolean,multiplier=1.2):number{return Math.floor(base*(active?multiplier:1));}
