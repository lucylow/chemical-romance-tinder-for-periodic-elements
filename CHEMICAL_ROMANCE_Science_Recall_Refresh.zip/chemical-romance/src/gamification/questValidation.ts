import type {QuestDefinition} from "./types";
export function validateQuest(q:QuestDefinition):string[] {
 const errors:string[]=[];if(!q.id)errors.push("Quest id is required");if(q.target<=0)errors.push("Target must be positive");
 if(!q.reward.length)errors.push("Quest needs a reward");if(!q.description)errors.push("Quest needs a description");return errors;
}
