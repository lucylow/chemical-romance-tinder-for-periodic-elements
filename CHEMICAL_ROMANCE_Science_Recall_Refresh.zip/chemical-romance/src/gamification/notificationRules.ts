export interface NotificationPreference {dailyReminder:boolean;streakReminder:boolean;quietStart:number;quietEnd:number;}
export function canSendReminder(p:NotificationPreference,hour:number):boolean {
 if(!p.dailyReminder)return false;
 if(p.quietStart===p.quietEnd)return true;
 return p.quietStart<p.quietEnd?hour<p.quietStart||hour>=p.quietEnd:hour>=p.quietEnd&&hour<p.quietStart;
}
