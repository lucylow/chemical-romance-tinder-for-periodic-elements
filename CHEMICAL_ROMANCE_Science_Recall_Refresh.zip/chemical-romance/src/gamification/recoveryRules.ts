export function missedDays(lastDate:string|null,today:string):number {
 if(!lastDate)return 0;const a=new Date(`${lastDate}T00:00:00Z`).getTime(),b=new Date(`${today}T00:00:00Z`).getTime();
 return Math.max(0,Math.round((b-a)/86400000)-1);
}
export function comebackMessage(days:number):string {
 if(days<=0)return "Welcome back. Your next discovery is waiting.";
 if(days<4)return "A little break is okay. Let's find your rhythm.";
 return "Welcome back to the lab. Start with one small win.";
}
