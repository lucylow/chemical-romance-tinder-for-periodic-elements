import type {GamificationState} from "./types";
import {levelFromXp} from "./leveling";
export function progressSnapshot(s:GamificationState) {
 const level=levelFromXp(s.totalXp);
 return {level:level.level,title:level.title,xp:s.totalXp,coins:s.wallet.coins,streak:s.streak.current,bestStreak:s.streak.best,badges:s.badges.length,inventory:s.inventory.length,questsCompleted:Object.values(s.quests).filter(q=>q.completed).length};
}
