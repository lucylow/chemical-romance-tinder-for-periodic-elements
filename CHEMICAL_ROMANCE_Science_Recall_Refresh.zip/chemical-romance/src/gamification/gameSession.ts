export interface SessionSummary {startedAt:string;endedAt:string;actions:number;xp:number;discoveries:number;}
export function summarizeSession(startedAt:string,endedAt:string,actions:number,xp:number,discoveries:number):SessionSummary {
 return {startedAt,endedAt,actions:Math.max(0,actions),xp:Math.max(0,xp),discoveries:Math.max(0,discoveries)};
}
