export interface Milestone {id:string;target:number;label:string;rewardXp:number;}
export const MILESTONES:Milestone[]=[
{id:"discover-10",target:10,label:"10 elements discovered",rewardXp:25},{id:"discover-25",target:25,label:"25 elements discovered",rewardXp:50},
{id:"discover-50",target:50,label:"Halfway to the full table",rewardXp:100},{id:"discover-118",target:118,label:"All 118 elements",rewardXp:300},
{id:"correct-100",target:100,label:"100 correct answers",rewardXp:100}
];
export function reachedMilestones(metric:string,value:number):Milestone[]{return MILESTONES.filter(m=>m.id.startsWith(metric)&&value>=m.target);}
