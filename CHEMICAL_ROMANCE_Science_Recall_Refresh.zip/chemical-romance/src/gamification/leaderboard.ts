export interface LeaderboardEntry {id:string;displayName:string;xp:number;level:number;isSelf?:boolean;}
export function rankEntries(entries:LeaderboardEntry[]):LeaderboardEntry[]{return [...entries].sort((a,b)=>b.xp-a.xp||a.displayName.localeCompare(b.displayName)).map((e,i)=>({...e,level:e.level}));}
export function playerRank(entries:LeaderboardEntry[],id:string):number {return rankEntries(entries).findIndex(e=>e.id===id)+1;}
