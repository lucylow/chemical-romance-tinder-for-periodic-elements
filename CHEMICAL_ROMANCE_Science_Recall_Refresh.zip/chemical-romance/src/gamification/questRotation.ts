import {QUEST_CATALOG} from "./questCatalog";
import {localDateKey} from "./date";
export function rotatingDailyQuests(date=new Date(),count=3) {
 const day=Number(localDateKey(date).replaceAll("-",""));
 const pool=QUEST_CATALOG.filter(q=>q.kind==="daily");
 return Array.from({length:Math.min(count,pool.length)},(_,i)=>pool[(day+i*2)%pool.length]);
}
