export interface FamilyMastery {family:string;total:number;discovered:number;percentage:number;}
export function familyMastery(family:string,ids:number[],discovered:number[]):FamilyMastery {
 const count=ids.filter(id=>discovered.includes(id)).length;return {family,total:ids.length,discovered:count,percentage:ids.length?Math.round(count/ids.length*100):0};
}
