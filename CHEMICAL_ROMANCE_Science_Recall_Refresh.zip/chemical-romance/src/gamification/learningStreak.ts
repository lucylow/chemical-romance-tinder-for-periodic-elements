export function learningStreakBonus(days:number):number{return days>=30?1.5:days>=7?1.25:days>=3?1.1:1;}
export function applyStreakBonus(xp:number,days:number):number{return Math.floor(xp*learningStreakBonus(days));}
