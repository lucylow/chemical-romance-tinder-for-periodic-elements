import type {GamificationState} from "./types";
export function completedDailyCount(s:GamificationState):number{return s.lifetime.daily_challenge_completed??0;}
export function completedQuestCount(s:GamificationState):number{return Object.values(s.quests).filter(x=>x.claimed).length;}
