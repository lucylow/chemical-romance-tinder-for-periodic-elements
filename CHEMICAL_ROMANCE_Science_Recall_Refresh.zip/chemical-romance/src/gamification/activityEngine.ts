import type { ActivityKind, ActivityResult, GamificationState, GameActivity } from "./types";
import { MAX_ACTIVITY_LOG, DAILY_XP_CAP } from "./constants";
import { addQuestActivity } from "./questEngine";
import { evaluateNewBadges, type BadgeStats } from "./badgeEngine";
import { REWARDS } from "./rewards";
import { updateStreak } from "./streakEngine";
type RewardKey = keyof typeof REWARDS;

const REWARD_FOR_ACTIVITY: Partial<Record<ActivityKind, RewardKey>> = {
  element_discovered: "discovery",
  element_liked: "like",
  element_matched: "match",
  quiz_correct: "quizCorrect",
  quiz_wrong: "quizWrong",
  formula_built: "formula",
  lesson_completed: "lesson",
  daily_challenge_completed: "daily",
  review_completed: "review",
  perfect_round: "perfectRound",
  boss_defeated: "boss",
};

export function recordActivity(
  state: GamificationState,
  kind: ActivityKind,
  amount = 1,
  metadata?: GameActivity["metadata"],
  date = new Date(),
): ActivityResult {
  const safeAmount = Math.floor(amount);
  if (!Number.isFinite(amount) || safeAmount <= 0) {
    return { state, xpAwarded: 0, coinsAwarded: 0, unlockedBadges: [], completedQuests: [] };
  }
  if (kind === "formula_built" && typeof metadata?.scenarioId === "string") {
    const alreadyRewarded = state.activity.some(
      (activity) => activity.kind === kind && activity.metadata?.scenarioId === metadata.scenarioId,
    );
    if (alreadyRewarded) {
      return { state, xpAwarded: 0, coinsAwarded: 0, unlockedBadges: [], completedQuests: [] };
    }
  }

  const rewardKey = REWARD_FOR_ACTIVITY[kind];
  const rule = rewardKey ? REWARDS[rewardKey] : { xp: 0, coins: 0 };
  const today = date.toISOString().slice(0, 10);
  const dayXp = state.activity
    .filter((activity) => activity.at.slice(0, 10) === today)
    .reduce((total, activity) => total + Number(activity.metadata?.xpAwarded ?? 0), 0);
  const xpAwarded = Math.max(0, Math.min(rule.xp * safeAmount, DAILY_XP_CAP - dayXp));
  const coinsAwarded = rule.coins * safeAmount;

  let next: GamificationState = {
    ...state,
    totalXp: state.totalXp + xpAwarded,
    wallet: {
      ...state.wallet,
      coins: state.wallet.coins + coinsAwarded,
      lifetimeEarned: state.wallet.lifetimeEarned + coinsAwarded,
    },
    updatedAt: date.toISOString(),
  };
  const questResult = addQuestActivity(next, kind, safeAmount, date);
  next = questResult.state;

  const activity: GameActivity = {
    id: `${date.getTime()}-${Math.random().toString(36).slice(2, 8)}`,
    kind,
    amount: safeAmount,
    at: date.toISOString(),
    metadata: { ...(metadata ?? {}), xpAwarded, coinsAwarded },
  };
  next = {
    ...next,
    activity: [...next.activity, activity].slice(-MAX_ACTIVITY_LOG),
    streak: updateStreak(next.streak, date),
  };

  const lifetime = { ...next.lifetime, [kind]: (next.lifetime[kind] ?? 0) + safeAmount };
  next = { ...next, lifetime };
  const stats: BadgeStats = {
    discoveries: lifetime.element_discovered ?? 0,
    matches: lifetime.element_matched ?? 0,
    correct: lifetime.quiz_correct ?? 0,
    perfectRounds: lifetime.perfect_round ?? 0,
    formulas: lifetime.formula_built ?? 0,
    bestStreak: next.streak.best,
    dailyChallenges: lifetime.daily_challenge_completed ?? 0,
    cosmetics: next.inventory.length,
    coinsEarned: next.wallet.lifetimeEarned,
    storyQuests: Object.entries(next.quests).filter(([id, progress]) => id.startsWith("story_") && progress.completed).length,
    families: lifetime.families_discovered ?? 0,
  };
  const badgeResult = evaluateNewBadges(next, stats);
  next = badgeResult.state;

  return {
    state: next,
    xpAwarded,
    coinsAwarded,
    unlockedBadges: badgeResult.unlocked,
    completedQuests: questResult.completed,
  };
}
