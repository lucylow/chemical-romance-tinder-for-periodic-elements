import type {GamificationState} from "./types";
import {rotatingDailyQuests} from "./questRotation";
import {questProgress} from "./questEngine";
export function dailyQuestBoard(s:GamificationState,date=new Date()) {
 return rotatingDailyQuests(date).map(q=>({quest:q,progress:questProgress(s,q,date)}));
}
