export interface PlayerIdentity {nickname:string;pronouns?:string;joinedAt:string;avatarId:string;}
export const DEFAULT_IDENTITY:PlayerIdentity={nickname:"New Chemist",joinedAt:new Date().toISOString(),avatarId:"avatar-atom"};
export function sanitizeNickname(value:string):string{return value.trim().replace(/[<>]/g,"").slice(0,18)||"New Chemist";}
