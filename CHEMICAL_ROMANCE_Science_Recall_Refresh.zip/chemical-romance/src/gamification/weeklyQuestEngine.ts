import {QUEST_CATALOG} from "./questCatalog";
export function weeklyQuestDefinitions(){return QUEST_CATALOG.filter(q=>q.kind==="weekly");}
