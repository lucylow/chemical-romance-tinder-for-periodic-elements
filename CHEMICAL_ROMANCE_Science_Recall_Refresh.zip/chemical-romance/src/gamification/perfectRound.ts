export function isPerfectRound(answers:boolean[],minimum=5):boolean{return answers.length>=minimum&&answers.every(Boolean);}
export function accuracyPercent(correct:number,total:number):number{return total<=0?0:Math.round(100*correct/total);}
export function starsForRound(correct:number,total:number):1|2|3 {const p=accuracyPercent(correct,total);return p>=95?3:p>=75?2:1;}
