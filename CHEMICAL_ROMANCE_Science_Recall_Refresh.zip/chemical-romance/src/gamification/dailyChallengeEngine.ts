import type { GamificationState } from "./types";
import { localDateKey } from "./date";
export interface DailyChallengeCard { id:string; title:string; instruction:string; target:number; rewardXp:number; rewardCoins:number; activity:string; }
const CHALLENGES:DailyChallengeCard[]=[
{id:"daily-symbols",title:"Symbol Speed-Date",instruction:"Recall element symbols without hints.",target:5,rewardXp:35,rewardCoins:10,activity:"quiz_correct"},
{id:"daily-families",title:"Find Your Family",instruction:"Identify three element families.",target:3,rewardXp:30,rewardCoins:9,activity:"family_correct"},
{id:"daily-lab",title:"Build a Bond",instruction:"Create a valid compound in the Lab.",target:1,rewardXp:30,rewardCoins:9,activity:"formula_built"},
{id:"daily-discovery",title:"New Faces",instruction:"Discover five element profiles.",target:5,rewardXp:25,rewardCoins:8,activity:"element_discovered"},
{id:"daily-memory",title:"No-Peeking Recall",instruction:"Complete five reviews without hints.",target:5,rewardXp:40,rewardCoins:12,activity:"review_completed"}
];
export function challengeForDate(date=new Date()):DailyChallengeCard {
  const seed=Number(localDateKey(date).replaceAll("-",""));
  return CHALLENGES[(seed*17+Math.floor(seed/7))%CHALLENGES.length];
}
export function challengeProgress(state:GamificationState,date=new Date()):number {
  const id=challengeForDate(date).id; return state.lifetime[`challenge:${id}:${localDateKey(date)}`]??0;
}
export function isChallengeComplete(state:GamificationState,date=new Date()):boolean{return challengeProgress(state,date)>=challengeForDate(date).target;}
