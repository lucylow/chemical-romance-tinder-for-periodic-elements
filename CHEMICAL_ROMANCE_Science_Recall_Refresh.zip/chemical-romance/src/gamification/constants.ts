export const GAMIFICATION_SCHEMA_VERSION = 1;
export const MAX_ACTIVITY_LOG = 250;
export const DAILY_XP_CAP = 500;
export const XP_PER_LEVEL = 120;
export const STREAK_FREEZE_PRICE = 80;
export const FIRST_RUN_BONUS_XP = 25;
export const LEVEL_TITLES = [
  "Periodic Newcomer", "Curious Atom", "Bond Beginner", "Electron Explorer",
  "Molecule Matchmaker", "Reaction Rookie", "Lab Romantic", "Element Expert",
  "Quantum Connector", "Master of Chemistry"
] as const;
export const RARITY_MULTIPLIERS = { common: 1, uncommon: 1.15, rare: 1.35, epic: 1.7, legendary: 2.25 } as const;
