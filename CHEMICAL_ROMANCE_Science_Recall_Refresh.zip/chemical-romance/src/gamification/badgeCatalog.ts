import type { BadgeDefinition } from "./types";
export const BADGE_CATALOG: BadgeDefinition[] = [
{ id: "first_crush", name: "First Crush", description: "Discover your first element.", icon: "💗", rarity: "common", rule: "discoveries>=1" },
{ id: "ten_faces", name: "Getting Popular", description: "Discover ten different elements.", icon: "🎭", rarity: "common", rule: "discoveries>=10" },
{ id: "fifty_faces", name: "Periodic Celebrity", description: "Discover fifty different elements.", icon: "🌟", rarity: "rare", rule: "discoveries>=50" },
{ id: "full_table", name: "The Whole Periodic World", description: "Discover all 118 elements.", icon: "🏆", rarity: "legendary", rule: "discoveries>=118" },
{ id: "first_match", name: "It's Mutual!", description: "Get your first mutual match.", icon: "💘", rarity: "common", rule: "matches>=1" },
{ id: "ten_matches", name: "Chemistry Is in the Air", description: "Get ten mutual matches.", icon: "💕", rarity: "uncommon", rule: "matches>=10" },
{ id: "quiz_starter", name: "Brain Spark", description: "Answer your first question correctly.", icon: "💡", rarity: "common", rule: "correct>=1" },
{ id: "quiz_ace", name: "Quiz Ace", description: "Answer 100 questions correctly.", icon: "🧠", rarity: "epic", rule: "correct>=100" },
{ id: "perfect_ten", name: "Perfect Ten", description: "Complete ten perfect rounds.", icon: "💎", rarity: "epic", rule: "perfectRounds>=10" },
{ id: "lab_apprentice", name: "Lab Apprentice", description: "Build your first valid compound.", icon: "⚗️", rarity: "common", rule: "formulas>=1" },
{ id: "lab_master", name: "Molecular Matchmaker", description: "Build 50 valid compounds.", icon: "🧬", rarity: "rare", rule: "formulas>=50" },
{ id: "week_warrior", name: "One Week Strong", description: "Reach a seven-day streak.", icon: "🔥", rarity: "uncommon", rule: "bestStreak>=7" },
{ id: "month_mind", name: "A Month of Chemistry", description: "Reach a 30-day streak.", icon: "🌙", rarity: "legendary", rule: "bestStreak>=30" },
{ id: "daily_devotee", name: "Daily Dater", description: "Complete ten daily challenges.", icon: "📅", rarity: "rare", rule: "dailyChallenges>=10" },
{ id: "collector", name: "Sticker Collector", description: "Own five cosmetic items.", icon: "🎀", rarity: "uncommon", rule: "cosmetics>=5" },
{ id: "coin_saver", name: "Tiny Treasure", description: "Earn 250 lab coins over time.", icon: "🪙", rarity: "uncommon", rule: "coinsEarned>=250" },
{ id: "story_reader", name: "Story Seeker", description: "Complete five story quests.", icon: "📖", rarity: "rare", rule: "storyQuests>=5" },
{ id: "family_friend", name: "Family Reunion", description: "Discover an element from all ten broad families.", icon: "🌈", rarity: "epic", rule: "families>=10" }
];
