import type {GamificationState} from "./types";
export function questBadgeStats(s:GamificationState) {
 const claimed=Object.values(s.quests).filter(q=>q.claimed).length;
 return {claimed,completed:Object.values(s.quests).filter(q=>q.completed).length,unclaimed:Object.values(s.quests).filter(q=>q.completed&&!q.claimed).length};
}
