export interface CalendarReward {day:number;coins:number;xp:number;label:string;}
export const REWARD_CALENDAR:CalendarReward[]=Array.from({length:7},(_,i)=>({day:i+1,coins:5+i*2,xp:10+i*5,label:["A spark","Tiny treat","Good chemistry","Midweek glow","High five","Big energy","A full heart"][i]}));
export function calendarReward(day:number):CalendarReward{return REWARD_CALENDAR[Math.max(0,Math.min(6,day-1))];}
