import type {GamificationState} from "./types";
export function questTimeline(s:GamificationState) {
 return Object.entries(s.quests).map(([key,p])=>({key,...p})).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));
}
