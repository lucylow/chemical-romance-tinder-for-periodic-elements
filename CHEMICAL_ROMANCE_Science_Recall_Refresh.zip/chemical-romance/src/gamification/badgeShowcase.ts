import {BADGE_CATALOG} from "./badgeCatalog";
import type {PlayerBadge} from "./types";
export function showcaseBadges(owned:PlayerBadge[],limit=3) {
 const ids=new Set(owned.map(x=>x.badgeId));return BADGE_CATALOG.filter(x=>ids.has(x.id)).slice(0,limit);
}
