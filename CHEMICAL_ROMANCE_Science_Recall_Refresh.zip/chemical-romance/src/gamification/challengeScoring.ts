export function challengeScore(correct:number,total:number,elapsedSeconds:number):number {
 if(total<=0)return 0;const accuracy=correct/total;const speed=Math.max(0,Math.min(20,20-elapsedSeconds/3));
 return Math.round(accuracy*80+speed);
}
