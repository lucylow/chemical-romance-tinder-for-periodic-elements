import type {GamificationState} from "./types";
import {seasonTier,seasonProgress} from "./seasonPass";
export function seasonSnapshot(s:GamificationState){return {tier:seasonTier(s.totalXp),progress:seasonProgress(s.totalXp),totalXp:s.totalXp};}
