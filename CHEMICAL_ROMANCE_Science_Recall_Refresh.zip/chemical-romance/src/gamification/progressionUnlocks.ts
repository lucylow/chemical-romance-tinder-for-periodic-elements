export interface UnlockRule {id:string;label:string;level:number;}
export const UNLOCK_RULES:UnlockRule[]=[
{id:"daily-quests",label:"Daily quests",level:1},{id:"streaks",label:"Streak calendar",level:2},
{id:"cosmetic-shop",label:"Cosmetic shop",level:3},{id:"family-bosses",label:"Family boss rounds",level:5},
{id:"season-collection",label:"Season collection",level:8},{id:"mastery-cards",label:"Mastery card frames",level:10}
];
export function unlockedFeatures(level:number):UnlockRule[]{return UNLOCK_RULES.filter(x=>level>=x.level);}
