export type PurchaseResult="success"|"already-owned"|"not-enough-coins";
export function purchaseResult(owned:boolean,balance:number,price:number):PurchaseResult {
 if(owned)return "already-owned";return balance>=price?"success":"not-enough-coins";
}
