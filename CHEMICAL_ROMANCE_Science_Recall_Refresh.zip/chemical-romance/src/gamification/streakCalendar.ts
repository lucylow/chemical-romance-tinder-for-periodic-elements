import type {GamificationState} from "./types";
import {localDateKey} from "./date";
export function activeDates(s:GamificationState):string[]{return [...new Set(s.activity.map(a=>a.at.slice(0,10)))].sort();}
export function hasPlayedToday(s:GamificationState,date=new Date()):boolean{return activeDates(s).includes(localDateKey(date));}
export function daysPlayedThisWeek(s:GamificationState,date=new Date()):number {
 const start=new Date(date);start.setDate(date.getDate()-((date.getDay()+6)%7));start.setHours(0,0,0,0);
 return activeDates(s).filter(k=>new Date(`${k}T00:00:00`).getTime()>=start.getTime()).length;
}
