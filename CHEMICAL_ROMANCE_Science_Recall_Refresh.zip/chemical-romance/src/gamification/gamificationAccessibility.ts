export function progressA11y(label:string,value:number,target:number):string {
 return `${label}: ${Math.min(value,target)} of ${target}, ${target?Math.round(Math.min(value,target)/target*100):0} percent complete`;
}
export function rewardA11y(xp:number,coins:number):string{return `Reward: ${xp} experience points and ${coins} lab coins`;}
