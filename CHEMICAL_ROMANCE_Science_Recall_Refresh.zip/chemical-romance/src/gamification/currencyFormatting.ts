export function formatCoins(n:number):string{return Math.max(0,Math.floor(n)).toLocaleString();}
export function formatXp(n:number):string{return `${Math.max(0,Math.floor(n)).toLocaleString()} XP`;}
