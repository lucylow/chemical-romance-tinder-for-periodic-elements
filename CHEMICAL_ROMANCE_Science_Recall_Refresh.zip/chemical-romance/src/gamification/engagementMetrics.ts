import type {GamificationState} from "./types";
export interface EngagementSummary {sessions:number;discoveries:number;correctAnswers:number;validFormulas:number;minutesActiveEstimate:number;}
export function engagementSummary(s:GamificationState):EngagementSummary {
 const count=(k:string)=>s.lifetime[k]??0;
 return {sessions:new Set(s.activity.map(a=>a.at.slice(0,10))).size,discoveries:count("element_discovered"),correctAnswers:count("quiz_correct"),validFormulas:count("formula_built"),minutesActiveEstimate:Math.max(0,Math.round(s.activity.length*0.7))};
}
