export interface CollectionSet {id:string;name:string;atomicNumbers:number[];rewardXp:number;rewardCoins:number;description:string;}
export const COLLECTION_SETS:CollectionSet[]=[
{id:"alkali",name:"Alkali Hearts",atomicNumbers:[3,11,19,37,55,87],rewardXp:60,rewardCoins:20,description:"Meet the alkali metals."},
{id:"noble",name:"Hard to Impress",atomicNumbers:[2,10,18,36,54,86,118],rewardXp:80,rewardCoins:25,description:"Collect the noble gases."},
{id:"halogens",name:"The Dramatic Ones",atomicNumbers:[9,17,35,53,85,117],rewardXp:60,rewardCoins:20,description:"Collect the halogens."},
{id:"period-two",name:"Second Period Social",atomicNumbers:[3,4,5,6,7,8,9,10],rewardXp:75,rewardCoins:20,description:"Complete Period 2."},
{id:"first-ten",name:"The First Ten",atomicNumbers:[1,2,3,4,5,6,7,8,9,10],rewardXp:50,rewardCoins:15,description:"Meet the first ten elements."}
];
export function collectionCount(set:CollectionSet,discovered:number[]):number{return set.atomicNumbers.filter(n=>discovered.includes(n)).length;}
export function collectionComplete(set:CollectionSet,discovered:number[]):boolean{return collectionCount(set,discovered)===set.atomicNumbers.length;}
