import type {GamificationState} from "./types";
export function claimWelcomeGift(s:GamificationState):GamificationState {
 if((s.lifetime.welcomeGift??0)>0)return s;
 return {...s,totalXp:s.totalXp+25,wallet:{...s.wallet,coins:s.wallet.coins+10,lifetimeEarned:s.wallet.lifetimeEarned+10},lifetime:{...s.lifetime,welcomeGift:1}};
}
