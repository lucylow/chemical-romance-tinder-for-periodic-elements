import type { GamificationState, StreakInfo } from "./types";
import { dayDifference, localDateKey } from "./date";
export function updateStreak(streak:StreakInfo,date=new Date()):StreakInfo {
  const today=localDateKey(date);
  if(streak.lastActiveDate===today)return streak;
  if(!streak.lastActiveDate)return {...streak,current:1,best:Math.max(1,streak.best),lastActiveDate:today};
  const gap=dayDifference(streak.lastActiveDate,today);
  if(gap===1)return {...streak,current:streak.current+1,best:Math.max(streak.best,streak.current+1),lastActiveDate:today};
  if(gap>1&&streak.freezes>0&&gap===2)return {...streak,current:streak.current+1,best:Math.max(streak.best,streak.current+1),freezes:streak.freezes-1,lastActiveDate:today};
  return {...streak,current:1,best:Math.max(streak.best,1),lastActiveDate:today};
}
export function streakMilestone(days:number):number { return [3,7,14,30,60,100].includes(days)?days:0; }
export function streakMessage(days:number):string {
  if(days>=30)return "A month of magnificent chemistry.";
  if(days>=7)return "One week of showing up. That's real progress.";
  if(days>=3)return "Three days in a row. The spark is real.";
  return "Come back tomorrow to keep the streak alive.";
}
