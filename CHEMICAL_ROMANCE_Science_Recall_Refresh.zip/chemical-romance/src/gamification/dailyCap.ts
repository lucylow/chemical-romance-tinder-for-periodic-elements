import type {GamificationState} from "./types";
import {DAILY_XP_CAP} from "./constants";
export function xpEarnedToday(s:GamificationState,date=new Date()):number {
 const key=date.toISOString().slice(0,10);
 return s.activity.filter(a=>a.at.slice(0,10)===key).reduce((sum,a)=>sum+Number(a.metadata?.xpAwarded??0),0);
}
export function remainingDailyXp(s:GamificationState,date=new Date()):number{return Math.max(0,DAILY_XP_CAP-xpEarnedToday(s,date));}
