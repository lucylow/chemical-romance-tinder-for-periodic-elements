import {activeSeasonalEvent} from "./seasonalEvents";
export function seasonalXp(base:number,date=new Date()):number {
 const event=activeSeasonalEvent(date);return Math.floor(base*(event?.bonusMultiplier??1));
}
