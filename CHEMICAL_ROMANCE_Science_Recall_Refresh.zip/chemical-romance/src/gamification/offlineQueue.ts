export interface PendingEvent {id:string;kind:string;payload:Record<string,unknown>;createdAt:string;}
export function enqueue(queue:PendingEvent[],event:PendingEvent,max=100):PendingEvent[]{return [...queue,event].slice(-max);}
export function dequeue(queue:PendingEvent[],id:string):PendingEvent[]{return queue.filter(x=>x.id!==id);}
