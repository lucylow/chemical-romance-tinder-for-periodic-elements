import type { CosmeticItem } from "./types";
export const COSMETICS:CosmeticItem[] = [
{id:"starter-frame",name:"First Date Frame",description:"A soft rose frame for your first profile cards.",price:0,rarity:"common",category:"card-frame",preview:"🌸"},
{id:"bubblegum-frame",name:"Bubblegum Crush",description:"A bright pink frame with a playful glow.",price:65,rarity:"uncommon",category:"card-frame",preview:"💗"},
{id:"starlight-frame",name:"Starlight Chemistry",description:"A constellation-inspired card border.",price:140,rarity:"rare",category:"card-frame",preview:"✨"},
{id:"neon-frame",name:"Neon Reaction",description:"A vivid lab-neon profile frame.",price:220,rarity:"epic",category:"card-frame",preview:"⚡"},
{id:"aurora-theme",name:"Aurora Lab",description:"A cool aurora palette for your profile.",price:120,rarity:"rare",category:"profile-theme",preview:"🌌"},
{id:"midnight-theme",name:"Midnight Molecule",description:"A deep midnight look with violet accents.",price:90,rarity:"uncommon",category:"profile-theme",preview:"🌙"},
{id:"rose-theme",name:"Rose Quartz",description:"A gentle rosy profile theme.",price:70,rarity:"uncommon",category:"profile-theme",preview:"🌹"},
{id:"heart-sticker",name:"Heart Atom",description:"A sticker for your element collection.",price:30,rarity:"common",category:"sticker",preview:"💘"},
{id:"flask-sticker",name:"Tiny Flask",description:"A little lab flask sticker.",price:35,rarity:"common",category:"sticker",preview:"⚗️"},
{id:"spark-sticker",name:"Spark of Genius",description:"A bright little achievement sticker.",price:55,rarity:"uncommon",category:"sticker",preview:"💡"},
{id:"title-curious",name:"Curious Atom",description:"A title displayed on your player profile.",price:80,rarity:"uncommon",category:"title",preview:"🔬"},
{id:"title-matchmaker",name:"Molecular Matchmaker",description:"A title earned by chemistry enthusiasts.",price:180,rarity:"rare",category:"title",preview:"🧬"}
];
export function cosmeticsByCategory(category:CosmeticItem["category"]):CosmeticItem[]{return COSMETICS.filter(x=>x.category===category);}
