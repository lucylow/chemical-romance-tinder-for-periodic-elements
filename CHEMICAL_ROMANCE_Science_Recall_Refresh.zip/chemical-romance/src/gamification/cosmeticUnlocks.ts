import type {CosmeticItem,GamificationState} from "./types";
export function isCosmeticOwned(s:GamificationState,item:CosmeticItem):boolean{return s.inventory.includes(item.id);}
export function isCosmeticEquipped(s:GamificationState,item:CosmeticItem):boolean{return s.equipped[item.category]===item.id;}
