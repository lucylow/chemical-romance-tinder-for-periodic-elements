export function titleForLevel(level:number):string {
 if(level>=30)return "Chemistry Icon";if(level>=20)return "Molecular Matchmaker";if(level>=10)return "Element Expert";
 if(level>=5)return "Lab Romantic";if(level>=3)return "Electron Explorer";return "Curious Atom";
}
