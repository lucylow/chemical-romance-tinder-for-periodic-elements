import type { GamificationState } from "./types";
export function createGamificationState(): GamificationState {
  return {
    schemaVersion: 1, totalXp: 0,
    wallet: { coins: 30, lifetimeEarned: 30, lifetimeSpent: 0 },
    streak: { current: 0, best: 0, freezes: 0, lastActiveDate: null },
    quests: {}, badges: [], inventory: ["starter-frame"], equipped: { "card-frame": "starter-frame", "profile-theme": null, title: null },
    activity: [], dailyClaimedAt: null, weeklyClaimedAt: null, lifetime: {}, updatedAt: new Date().toISOString()
  };
}
export function migrateGamificationState(raw: unknown): GamificationState {
  const base = createGamificationState();
  if (!raw || typeof raw !== "object") return base;
  const value = raw as Partial<GamificationState>;
  return {
    ...base, ...value, schemaVersion: 1,
    wallet: { ...base.wallet, ...(value.wallet ?? {}) },
    streak: { ...base.streak, ...(value.streak ?? {}) },
    quests: value.quests ?? {}, badges: value.badges ?? [], inventory: value.inventory ?? base.inventory,
    equipped: { ...base.equipped, ...(value.equipped ?? {}) }, activity: Array.isArray(value.activity) ? value.activity : [],
    lifetime: value.lifetime ?? {}
  };
}
