import type {GamificationState} from "./types";
export function exportProgress(s:GamificationState):string{return JSON.stringify({schemaVersion:s.schemaVersion,totalXp:s.totalXp,wallet:s.wallet,streak:s.streak,badges:s.badges,inventory:s.inventory,lifetime:s.lifetime},null,2);}
