import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import type { ActivityKind, ActivityResult, GamificationState } from "./types";
import { createGamificationState, migrateGamificationState } from "./defaultState";
import { recordActivity } from "./activityEngine";
import { claimDailyReward } from "./claimRewards";
import { claimQuest } from "./questEngine";
import { purchase, equip } from "./economy";
import { COSMETICS } from "./cosmetics";
import { buyStreakFreeze } from "./streakFreeze";

const STORAGE_KEY = "@chemical-romance/gamification-v1";

type Metadata = Record<string, string | number | boolean>;
type ContextValue = {
  state: GamificationState;
  loading: boolean;
  record: (kind: ActivityKind, amount?: number, metadata?: Metadata) => ActivityResult;
  claimDaily: () => { claimed: boolean; xp: number; coins: number };
  claim: (questId: string) => boolean;
  buy: (itemId: string) => boolean;
  wear: (itemId: string) => void;
  buyFreeze: () => boolean;
  reset: () => void;
};

const Ctx = createContext<ContextValue | null>(null);

export function GamificationProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState(createGamificationState);
  const [loading, setLoading] = useState(true);
  const stateRef = useRef(state);
  stateRef.current = state;

  const commit = useCallback((next: GamificationState) => {
    stateRef.current = next;
    setState(next);
  }, []);

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!mounted || !raw) return;
        try {
          const restored = migrateGamificationState(JSON.parse(raw));
          stateRef.current = restored;
          setState(restored);
        } catch {
          const fresh = createGamificationState();
          stateRef.current = fresh;
          setState(fresh);
        }
      })
      .catch(() => {
        // Keep the usable in-memory default if local storage is unavailable.
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!loading) {
      AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state)).catch(() => {
        // Storage failures should not interrupt the current learning session.
      });
    }
  }, [state, loading]);

  const record = useCallback(
    (kind: ActivityKind, amount = 1, metadata?: Metadata) => {
      const result = recordActivity(stateRef.current, kind, amount, metadata);
      commit(result.state);
      return result;
    },
    [commit],
  );

  const claimDaily = useCallback(() => {
    const result = claimDailyReward(stateRef.current);
    commit(result.state);
    return { claimed: result.claimed, xp: result.xp, coins: result.coins };
  }, [commit]);

  const claim = useCallback(
    (id: string) => {
      const result = claimQuest(stateRef.current, id);
      if (!result.quest) return false;

      let next = result.state;
      for (const reward of result.quest.reward) {
        if (reward.kind === "xp") {
          next = { ...next, totalXp: next.totalXp + (reward.amount ?? 0) };
        } else if (reward.kind === "coins") {
          const amount = reward.amount ?? 0;
          next = {
            ...next,
            wallet: {
              ...next.wallet,
              coins: next.wallet.coins + amount,
              lifetimeEarned: next.wallet.lifetimeEarned + amount,
            },
          };
        }
      }
      commit(next);
      return true;
    },
    [commit],
  );

  const buy = useCallback(
    (id: string) => {
      const item = COSMETICS.find((candidate) => candidate.id === id);
      if (!item) return false;
      const current = stateRef.current;
      const next = purchase(current, item);
      if (next === current) return false;
      commit(next);
      return true;
    },
    [commit],
  );

  const wear = useCallback(
    (id: string) => {
      const item = COSMETICS.find((candidate) => candidate.id === id);
      if (item) commit(equip(stateRef.current, item));
    },
    [commit],
  );

  const buyFreeze = useCallback(() => {
    const current = stateRef.current;
    const next = buyStreakFreeze(current);
    if (next === current) return false;
    commit(next);
    return true;
  }, [commit]);

  const reset = useCallback(() => commit(createGamificationState()), [commit]);
  const value = useMemo(
    () => ({ state, loading, record, claimDaily, claim, buy, wear, buyFreeze, reset }),
    [state, loading, record, claimDaily, claim, buy, wear, buyFreeze, reset],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useGamification() {
  const value = useContext(Ctx);
  if (!value) throw new Error("useGamification must be inside GamificationProvider");
  return value;
}
