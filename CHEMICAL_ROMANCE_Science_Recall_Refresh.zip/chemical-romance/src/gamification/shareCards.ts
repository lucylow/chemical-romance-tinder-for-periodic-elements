export interface ShareCardData {headline:string;subline:string;statLabel:string;statValue:string;footer:string;}
export function makeLevelShareCard(level:number,title:string,xp:number):ShareCardData {
 return {headline:"CHEMICAL ROMANCE",subline:title,statLabel:"PLAYER LEVEL",statValue:String(level),footer:`${xp.toLocaleString()} XP earned • Chemistry looks good on you`};
}
