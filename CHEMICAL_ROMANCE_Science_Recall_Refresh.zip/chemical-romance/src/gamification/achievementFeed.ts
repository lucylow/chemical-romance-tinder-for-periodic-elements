import type {BadgeDefinition,GameActivity} from "./types";
export type FeedItem={id:string;type:"badge"|"activity";title:string;detail:string;at:string};
export function buildAchievementFeed(activities:GameActivity[],badges:BadgeDefinition[]):FeedItem[] {
 const a=activities.map(x=>({id:x.id,type:"activity" as const,title:x.kind.replaceAll("_"," "),detail:`+${x.amount} progress`,at:x.at}));
 return a.sort((x,y)=>y.at.localeCompare(x.at));
}
