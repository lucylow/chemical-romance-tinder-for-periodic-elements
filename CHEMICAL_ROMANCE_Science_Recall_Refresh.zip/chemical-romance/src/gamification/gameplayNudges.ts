export function nextNudge(input:{discovered:number;correct:number;formulas:number;streak:number}):string {
 if(input.discovered<5)return "Meet five elements to unlock your first collection reward.";
 if(input.correct<10)return "Try Memory Lane to strengthen element-name recall.";
 if(input.formulas<1)return "Visit the Lab and build your first compound.";
 if(input.streak<3)return "A few minutes tomorrow can keep your streak going.";
 return "Pick a family collection and complete the set.";
}
