import React,{useState} from "react";
import {Text,View,ScrollView,StyleSheet} from "react-native";
import {Screen} from "../../components/Screen";
import {useGamification} from "../GamificationContext";
import {COSMETICS} from "../cosmetics";
import {ShopItem} from "../components/ShopItem";
import {WalletPill} from "../components/WalletPill";
import {colors} from "../../theme/colors";
export function ShopScreen(){
 const {state,buy,wear}=useGamification();const [category,setCategory]=useState("all");
 const items=COSMETICS.filter(x=>category==="all"||x.category===category);
 return <Screen><View style={s.header}><View><Text style={s.heading}>The little shop</Text><Text style={s.sub}>Cute cosmetics. No pay-to-win boosts.</Text></View><WalletPill coins={state.wallet.coins}/></View>
 <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{maxHeight:42}} contentContainerStyle={{gap:8}}>{["all","card-frame","profile-theme","sticker","title"].map(x=><Text key={x} onPress={()=>setCategory(x)} style={[s.filter,category===x&&s.active]}>{x.replace("-"," ")}</Text>)}</ScrollView>
 <View style={s.grid}>{items.map(item=>{const owned=state.inventory.includes(item.id);return <ShopItem key={item.id} item={item} owned={owned} canAfford={state.wallet.coins>=item.price} equipped={state.equipped[item.category]===item.id} onBuy={()=>buy(item.id)} onEquip={()=>wear(item.id)}/>})}</View>
 </Screen>;
}
const s=StyleSheet.create({header:{flexDirection:"row",justifyContent:"space-between",alignItems:"center",marginBottom:15},heading:{fontSize:28,fontWeight:"900",color:colors.text},sub:{color:colors.muted,fontSize:12,marginTop:4},filter:{color:colors.muted,backgroundColor:colors.surface2,paddingHorizontal:13,paddingVertical:9,borderRadius:18,overflow:"hidden",textTransform:"capitalize"},active:{backgroundColor:colors.pink,color:"#fff"},grid:{flexDirection:"row",flexWrap:"wrap",justifyContent:"space-between",gap:10,marginTop:18}});
