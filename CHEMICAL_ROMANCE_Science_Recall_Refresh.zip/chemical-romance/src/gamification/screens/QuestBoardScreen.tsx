import React from "react";
import {Text,View,StyleSheet} from "react-native";
import {Screen} from "../../components/Screen";
import {useGamification} from "../GamificationContext";
import {QUEST_CATALOG} from "../questCatalog";
import {questProgress} from "../questEngine";
import {QuestCard} from "../components/QuestCard";
import {colors} from "../../theme/colors";
export function QuestBoardScreen() {
 const {state,claim}=useGamification();
 const daily=QUEST_CATALOG.filter(q=>q.kind==="daily"),weekly=QUEST_CATALOG.filter(q=>q.kind==="weekly"),story=QUEST_CATALOG.filter(q=>q.kind!=="daily"&&q.kind!=="weekly");
 return <Screen><Text style={s.heading}>Quest board</Text><Text style={s.sub}>Little missions. Real chemistry knowledge.</Text>
 <Section title="DAILY QUESTS" items={daily}/><Section title="WEEKLY QUESTS" items={weekly}/><Section title="STORY & MASTERY" items={story}/>
 </Screen>;
 function Section({title,items}:{title:string;items:typeof QUEST_CATALOG}){return <View style={{gap:10,marginTop:22}}><Text style={s.section}>{title}</Text>{items.map(q=><QuestCard key={q.id} quest={q} progress={questProgress(state,q)} onClaim={()=>claim(q.id)}/>)}</View>;}
}
const s=StyleSheet.create({heading:{fontSize:28,fontWeight:"900",color:colors.text},sub:{color:colors.muted,marginTop:4},section:{color:colors.pinkSoft,fontWeight:"900",letterSpacing:1.4,fontSize:11}});
