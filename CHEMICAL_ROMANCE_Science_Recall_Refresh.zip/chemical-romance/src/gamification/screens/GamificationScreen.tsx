import React from "react";
import {View,Text,StyleSheet,Pressable} from "react-native";
import {useRouter} from "expo-router";
import {Screen} from "../../components/Screen";
import {useGamification} from "../GamificationContext";
import {LevelProgress} from "../components/LevelProgress";
import {StreakCard} from "../components/StreakCard";
import {ProgressStat} from "../components/ProgressStat";
import {progressSnapshot} from "../progressSnapshot";
import {colors} from "../../theme/colors";
export function GamificationScreen() {
 const {state}=useGamification();const p=progressSnapshot(state);const router=useRouter();
 return <Screen><Text style={s.eyebrow}>CHEMICAL ROMANCE</Text><Text style={s.heading}>Your love story with chemistry.</Text>
 <LevelProgress xp={state.totalXp}/><StreakCard current={p.streak} best={p.bestStreak} freezes={state.streak.freezes}/>
 <View style={s.stats}><ProgressStat label="Lab coins" value={p.coins} icon="🪙"/><ProgressStat label="Badges" value={p.badges} icon="🏅"/><ProgressStat label="Quests" value={p.questsCompleted} icon="🗺️"/></View>
 <View style={s.links}>{[["Quests","/quests"],["Badges","/badges"],["Shop","/shop"]].map(([label,path])=><Pressable key={path} accessibilityRole="button" onPress={()=>router.push(path as "/quests"|"/badges"|"/shop")} style={s.link}><Text style={s.linkText}>{label} →</Text></Pressable>)}</View>
 <Text style={s.section}>YOUR STATS</Text><View style={s.panel}><Row label="Elements discovered" value={state.lifetime.element_discovered??0}/><Row label="Correct answers" value={state.lifetime.quiz_correct??0}/><Row label="Compounds built" value={state.lifetime.formula_built??0}/><Row label="Mutual matches" value={state.lifetime.element_matched??0}/></View>
 </Screen>;
}
function Row({label,value}:{label:string;value:number}){return <View style={s.row}><Text style={s.rowLabel}>{label}</Text><Text style={s.rowValue}>{value}</Text></View>;}
const s=StyleSheet.create({eyebrow:{color:colors.pink,fontWeight:"900",letterSpacing:2,fontSize:10},heading:{color:colors.text,fontWeight:"900",fontSize:27,marginTop:8,marginBottom:18},stats:{flexDirection:"row",gap:8,marginTop:14},links:{flexDirection:"row",gap:8,marginTop:14},link:{flex:1,alignItems:"center",paddingVertical:12,borderRadius:13,backgroundColor:colors.surface2,borderWidth:1,borderColor:colors.border},linkText:{color:colors.pinkSoft,fontWeight:"800",fontSize:12},section:{color:colors.pinkSoft,fontWeight:"900",letterSpacing:1.5,marginTop:25,marginBottom:10},panel:{backgroundColor:colors.surface,borderRadius:18,padding:15,borderWidth:1,borderColor:colors.border},row:{flexDirection:"row",justifyContent:"space-between",paddingVertical:11,borderBottomWidth:1,borderBottomColor:colors.border},rowLabel:{color:colors.muted},rowValue:{color:colors.text,fontWeight:"900"}});
