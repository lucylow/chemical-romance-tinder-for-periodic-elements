import React from "react";
import {Text,View,StyleSheet} from "react-native";
import {Screen} from "../../components/Screen";
import {useGamification} from "../GamificationContext";
import {BADGE_CATALOG} from "../badgeCatalog";
import {BadgeTile} from "../components/BadgeTile";
import {colors} from "../../theme/colors";
export function BadgeGalleryScreen(){
 const {state}=useGamification();const owned=new Set(state.badges.map(x=>x.badgeId));
 return <Screen><Text style={s.heading}>Badge gallery</Text><Text style={s.sub}>{owned.size} of {BADGE_CATALOG.length} unlocked</Text>
 <View style={s.grid}>{BADGE_CATALOG.map(b=><BadgeTile key={b.id} badge={b} unlocked={owned.has(b.id)}/>)}</View></Screen>;
}
const s=StyleSheet.create({heading:{fontSize:28,fontWeight:"900",color:colors.text},sub:{color:colors.muted,marginVertical:8},grid:{flexDirection:"row",flexWrap:"wrap",gap:9,justifyContent:"space-between"}});
