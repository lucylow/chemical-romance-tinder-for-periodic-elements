import type {GamificationState} from "./types";
import {levelFromXp} from "./leveling";
export const selectLevel=(s:GamificationState)=>levelFromXp(s.totalXp);
export const selectCoins=(s:GamificationState)=>s.wallet.coins;
export const selectBadges=(s:GamificationState)=>s.badges;
export const selectCurrentStreak=(s:GamificationState)=>s.streak.current;
