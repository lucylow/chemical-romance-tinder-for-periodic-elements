import type { ActivityKind, GamificationState, QuestDefinition, QuestProgress } from "./types";
import { QUEST_CATALOG } from "./questCatalog";
import { localDateKey, weekKey } from "./date";
export function ensureQuestProgress(state:GamificationState, date=new Date()):GamificationState {
  const quests={...state.quests}; const today=localDateKey(date), week=weekKey(date);
  for(const q of QUEST_CATALOG){
    const key=q.kind==="daily"?today:q.kind==="weekly"?week:"lifetime";
    const id=`${q.id}:${key}`;
    if(!quests[id]) quests[id]={questId:q.id,value:0,completed:false,claimed:false,updatedAt:date.toISOString()};
  }
  return {...state,quests};
}
export function addQuestActivity(state:GamificationState, activity:ActivityKind, amount=1, date=new Date()):{state:GamificationState;completed:QuestDefinition[]} {
  const next=ensureQuestProgress(state,date), completed:QuestDefinition[]=[];
  const quests={...next.quests}, today=localDateKey(date), week=weekKey(date);
  for(const q of QUEST_CATALOG.filter(x=>x.activity===activity)){
    const key=q.kind==="daily"?today:q.kind==="weekly"?week:"lifetime", id=`${q.id}:${key}`;
    const p=quests[id] ?? {questId:q.id,value:0,completed:false,claimed:false,updatedAt:date.toISOString()};
    const value=Math.min(q.target,p.value+amount), done=value>=q.target;
    quests[id]={...p,value,completed:done,updatedAt:date.toISOString()};
    if(done&&!p.completed) completed.push(q);
  }
  return {state:{...next,quests},completed};
}
export function claimQuest(state:GamificationState, questId:string, date=new Date()):{state:GamificationState;quest:QuestDefinition|null} {
  const q=QUEST_CATALOG.find(x=>x.id===questId); if(!q)return {state,quest:null};
  const key=q.kind==="daily"?localDateKey(date):q.kind==="weekly"?weekKey(date):"lifetime", id=`${q.id}:${key}`;
  const p=state.quests[id]; if(!p?.completed||p.claimed)return {state,quest:null};
  return {state:{...state,quests:{...state.quests,[id]:{...p,claimed:true,updatedAt:date.toISOString()}}},quest:q};
}
export function questProgress(state:GamificationState,q:QuestDefinition,date=new Date()):QuestProgress {
  const key=q.kind==="daily"?localDateKey(date):q.kind==="weekly"?weekKey(date):"lifetime";
  return state.quests[`${q.id}:${key}`]??{questId:q.id,value:0,completed:false,claimed:false,updatedAt:date.toISOString()};
}
