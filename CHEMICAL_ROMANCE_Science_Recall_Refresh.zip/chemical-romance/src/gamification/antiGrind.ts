export interface RewardInput {baseXp:number;repeatedSameQuestion:boolean;hintUsed:boolean;elapsedMs:number;}
export function fairReward(input:RewardInput):number {
 let xp=Math.max(0,input.baseXp);if(input.repeatedSameQuestion)xp=Math.floor(xp*0.25);
 if(input.hintUsed)xp=Math.floor(xp*0.7);if(input.elapsedMs<500)xp=Math.floor(xp*0.5);
 return xp;
}
