export function progressEncouragement(progress:number):string {
 if(progress>=1)return "Complete! You did it.";
 if(progress>=0.75)return "So close — one more push.";
 if(progress>=0.4)return "You're building momentum.";
 return "Every small step counts.";
}
