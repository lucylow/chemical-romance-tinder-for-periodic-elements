export function scoreForQuiz(correct:boolean,elapsedMs:number,hints:number):number {
 if(!correct)return 0;const speed=elapsedMs<3000?4:elapsedMs<8000?2:0;return Math.max(2,10+speed-hints*2);
}
export function starsFromScore(score:number,max:number):number {
 const p=max?score/max:0;return p>=.9?3:p>=.65?2:p>=.35?1:0;
}
