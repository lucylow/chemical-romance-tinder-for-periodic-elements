import React from "react";
import {View,Text,StyleSheet} from "react-native";
import type {RewardBurst} from "../rewardAnimation";
import {colors} from "../../theme/colors";
export function RewardToast({items}:{items:RewardBurst[]}) {
 if(!items.length)return null;
 return <View accessibilityLiveRegion="polite" style={s.wrap}>{items.map((x,i)=><View key={`${x.kind}-${i}`} style={s.pill}><Text style={s.text}>{x.label}</Text></View>)}</View>;
}
const s=StyleSheet.create({wrap:{gap:6},pill:{backgroundColor:colors.surface2,borderColor:colors.gold,borderWidth:1,borderRadius:12,padding:10},text:{color:colors.gold,fontWeight:"900",textAlign:"center"}});
