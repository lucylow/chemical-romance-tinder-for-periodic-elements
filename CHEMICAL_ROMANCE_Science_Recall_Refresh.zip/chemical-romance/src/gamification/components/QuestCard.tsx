import React from "react";
import {View,Text,Pressable,StyleSheet} from "react-native";
import type {QuestDefinition,QuestProgress} from "../types";
import {progressRatio} from "../questProgressMath";
import {colors} from "../../theme/colors";
export function QuestCard({quest,progress,onClaim}:{quest:QuestDefinition;progress:QuestProgress;onClaim?:()=>void}) {
 const ratio=progressRatio(progress.value,quest.target);
 return <View style={s.card}><View style={s.top}><Text style={s.icon}>{quest.icon}</Text><View style={{flex:1}}><Text style={s.title}>{quest.title}</Text><Text style={s.desc}>{quest.description}</Text></View><Text style={s.count}>{Math.min(progress.value,quest.target)}/{quest.target}</Text></View>
 <View style={s.track}><View style={[s.fill,{width:`${ratio*100}%`}]}/></View>
 <View style={s.bottom}><Text style={s.reward}>{quest.reward.map(r=>r.kind==="xp"?`✦ ${r.amount} XP`:`◈ ${r.amount} coins`).join("  ")}</Text>
 {progress.completed&&!progress.claimed&&onClaim?<Pressable accessibilityRole="button" onPress={onClaim} style={s.button}><Text style={s.buttonText}>Claim</Text></Pressable>:<Text style={s.status}>{progress.claimed?"Collected":progress.completed?"Complete":"In progress"}</Text>}</View></View>;
}
const s=StyleSheet.create({card:{backgroundColor:colors.surface,borderRadius:18,borderWidth:1,borderColor:colors.border,padding:14,gap:12},top:{flexDirection:"row",alignItems:"center",gap:10},icon:{fontSize:25},title:{color:colors.text,fontWeight:"800",fontSize:15},desc:{color:colors.muted,fontSize:12,marginTop:3},count:{color:colors.cyan,fontWeight:"800"},track:{height:7,backgroundColor:colors.surface2,borderRadius:10,overflow:"hidden"},fill:{height:7,backgroundColor:colors.violet,borderRadius:10},bottom:{flexDirection:"row",justifyContent:"space-between",alignItems:"center"},reward:{color:colors.gold,fontSize:11,fontWeight:"700"},status:{color:colors.muted,fontSize:11},button:{backgroundColor:colors.pink,paddingHorizontal:14,paddingVertical:7,borderRadius:20},buttonText:{color:"#fff",fontWeight:"800",fontSize:12}});
