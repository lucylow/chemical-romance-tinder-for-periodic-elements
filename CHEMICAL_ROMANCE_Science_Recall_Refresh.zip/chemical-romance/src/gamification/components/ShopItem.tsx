import React from "react";
import {View,Text,Pressable,StyleSheet} from "react-native";
import type {CosmeticItem} from "../types";
import {colors} from "../../theme/colors";
export function ShopItem({item,owned,canAfford,onBuy,onEquip,equipped}:{item:CosmeticItem;owned:boolean;canAfford:boolean;onBuy:()=>void;onEquip:()=>void;equipped:boolean}) {
 return <View style={s.card}><Text style={s.preview}>{item.preview}</Text><Text style={s.name}>{item.name}</Text><Text style={s.desc}>{item.description}</Text>
 <Pressable accessibilityRole="button" disabled={!owned&&!canAfford} onPress={owned?onEquip:onBuy} style={[s.button,(!owned&&!canAfford)&&s.disabled]}><Text style={s.btnText}>{equipped?"Equipped":owned?"Equip":`${item.price} 🪙`}</Text></Pressable></View>;
}
const s=StyleSheet.create({card:{width:150,backgroundColor:colors.surface,borderRadius:18,padding:13,borderWidth:1,borderColor:colors.border,alignItems:"center",gap:7},preview:{fontSize:34},name:{color:colors.text,fontWeight:"900",fontSize:13,textAlign:"center"},desc:{color:colors.muted,fontSize:10,textAlign:"center",minHeight:30},button:{backgroundColor:colors.pink,paddingVertical:8,paddingHorizontal:16,borderRadius:18},disabled:{opacity:.4},btnText:{color:"#fff",fontWeight:"900",fontSize:11}});
