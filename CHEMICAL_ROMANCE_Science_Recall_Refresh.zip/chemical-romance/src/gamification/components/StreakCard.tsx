import React from "react";
import {View,Text,StyleSheet} from "react-native";
import {colors} from "../../theme/colors";
export function StreakCard({current,best,freezes}:{current:number;best:number;freezes:number}) {
 return <View style={s.card}><View style={s.icon}><Text style={{fontSize:27}}>🔥</Text></View><View style={{flex:1}}><Text style={s.title}>{current} day streak</Text><Text style={s.sub}>Best: {best} days · {freezes} streak freezes</Text></View><Text style={s.spark}>✦</Text></View>;
}
const s=StyleSheet.create({card:{flexDirection:"row",alignItems:"center",gap:12,backgroundColor:colors.surface,borderColor:colors.border,borderWidth:1,borderRadius:18,padding:15},icon:{width:48,height:48,borderRadius:16,backgroundColor:"#493026",alignItems:"center",justifyContent:"center"},title:{color:colors.text,fontWeight:"900",fontSize:17},sub:{color:colors.muted,fontSize:11,marginTop:4},spark:{fontSize:23,color:colors.gold}});
