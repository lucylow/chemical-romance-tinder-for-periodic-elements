import React from "react";
import {View,Text,StyleSheet} from "react-native";
import {colors} from "../../theme/colors";
export function ProgressStat({label,value,icon}:{label:string;value:string|number;icon:string}) {
 return <View style={s.box}><Text style={s.icon}>{icon}</Text><Text style={s.value}>{value}</Text><Text style={s.label}>{label}</Text></View>;
}
const s=StyleSheet.create({box:{flex:1,minWidth:90,backgroundColor:colors.surface,borderRadius:16,padding:13,borderWidth:1,borderColor:colors.border,alignItems:"center",gap:5},icon:{fontSize:20},value:{fontSize:19,color:colors.text,fontWeight:"900"},label:{fontSize:10,color:colors.muted,fontWeight:"700"}});
