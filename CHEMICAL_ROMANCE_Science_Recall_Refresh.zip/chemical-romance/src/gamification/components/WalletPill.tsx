import React from "react";
import {View,Text,StyleSheet} from "react-native";
import {colors} from "../../theme/colors";
export function WalletPill({coins}:{coins:number}) {return <View style={s.pill}><Text>🪙</Text><Text style={s.text}>{coins.toLocaleString()}</Text></View>;}
const s=StyleSheet.create({pill:{flexDirection:"row",alignItems:"center",gap:6,backgroundColor:colors.surface2,paddingHorizontal:12,paddingVertical:8,borderRadius:20},text:{color:colors.gold,fontWeight:"900"}});
