import React from "react";
import {View,Text,StyleSheet} from "react-native";
import type {BadgeDefinition} from "../types";
import {colors} from "../../theme/colors";
export function BadgeTile({badge,unlocked}:{badge:BadgeDefinition;unlocked:boolean}) {
 return <View style={[s.tile,!unlocked&&s.locked]}><Text style={s.icon}>{unlocked?badge.icon:"🔒"}</Text><Text style={s.name}>{badge.name}</Text><Text style={s.rarity}>{unlocked?badge.rarity.toUpperCase():"LOCKED"}</Text></View>;
}
const s=StyleSheet.create({tile:{width:108,minHeight:112,padding:10,alignItems:"center",justifyContent:"center",backgroundColor:colors.surface,borderRadius:16,borderWidth:1,borderColor:colors.border,gap:6},locked:{opacity:.5},icon:{fontSize:27},name:{color:colors.text,fontWeight:"800",fontSize:11,textAlign:"center"},rarity:{color:colors.gold,fontSize:8,fontWeight:"900",letterSpacing:1}});
