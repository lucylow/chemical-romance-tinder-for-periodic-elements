import React from "react";
import {View,Text,StyleSheet} from "react-native";
import {levelFromXp} from "../leveling";
import {colors} from "../../theme/colors";
export function LevelProgress({xp}:{xp:number}) {
 const l=levelFromXp(xp);
 return <View style={s.card}><View style={s.row}><View><Text style={s.kicker}>YOUR CHEMISTRY ERA</Text><Text style={s.title}>Level {l.level} · {l.title}</Text></View><Text style={s.xp}>{xp.toLocaleString()} XP</Text></View>
 <View style={s.track}><View style={[s.fill,{width:`${l.progress*100}%`}]}/></View><Text style={s.caption}>{Math.max(0,l.nextLevelXp-xp)} XP to your next level</Text></View>;
}
const s=StyleSheet.create({card:{backgroundColor:colors.surface,borderColor:colors.border,borderWidth:1,borderRadius:20,padding:16,gap:10},row:{flexDirection:"row",justifyContent:"space-between",alignItems:"center"},kicker:{color:colors.pinkSoft,fontSize:10,fontWeight:"800",letterSpacing:1.5},title:{color:colors.text,fontSize:17,fontWeight:"800",marginTop:4},xp:{color:colors.gold,fontWeight:"800"},track:{height:9,borderRadius:20,backgroundColor:colors.surface2,overflow:"hidden"},fill:{height:9,backgroundColor:colors.pink,borderRadius:20},caption:{color:colors.muted,fontSize:12}});
