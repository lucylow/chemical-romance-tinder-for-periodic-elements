export type Difficulty="warm-up"|"standard"|"challenge"|"expert";
const multiplier:Record<Difficulty,number>={"warm-up":0.8,standard:1,challenge:1.3,expert:1.7};
export function difficultyXp(base:number,difficulty:Difficulty):number{return Math.round(base*multiplier[difficulty]);}
