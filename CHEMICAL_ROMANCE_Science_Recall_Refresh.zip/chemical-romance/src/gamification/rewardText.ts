export function xpText(xp:number):string{return `${xp.toLocaleString()} XP`;}
export function coinText(coins:number):string{return `${coins.toLocaleString()} lab coins`;}
export function levelText(level:number):string{return `Level ${level}`;}
