export function localDateKey(date = new Date()): string {
  const y = date.getFullYear(), m = String(date.getMonth() + 1).padStart(2, "0"), d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}
export function dayDifference(a: string, b: string): number {
  const parse = (s: string) => { const [y,m,d] = s.split("-").map(Number); return Date.UTC(y,m-1,d); };
  return Math.round((parse(b) - parse(a)) / 86400000);
}
export function weekKey(date = new Date()): string {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const day = d.getUTCDay() || 7; d.setUTCDate(d.getUTCDate() - day + 1);
  return d.toISOString().slice(0,10);
}
export function isSameDay(a: string | null, b = new Date()): boolean { return !!a && a === localDateKey(b); }
