import type {GamificationState} from "./types";
import {weekKey} from "./date";
export function weeklySummary(s:GamificationState,date=new Date()) {
 const start=weekKey(date),events=s.activity.filter(a=>a.at.slice(0,10)>=start);
 return {weekStarting:start,events:events.length,xp:events.reduce((n,a)=>n+Number(a.metadata?.xpAwarded??0),0),
 discoveries:events.filter(a=>a.kind==="element_discovered").reduce((n,a)=>n+a.amount,0),
 correct:events.filter(a=>a.kind==="quiz_correct").reduce((n,a)=>n+a.amount,0)};
}
