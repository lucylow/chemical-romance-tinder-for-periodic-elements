export const REWARD_SCHEDULE={dailyQuestResetHour:0,weeklyQuestResetDay:1,weeklyQuestResetHour:0,timezone:"device-local"};
export function resetBoundaryCopy():string{return "Challenges reset using your device's local calendar.";}
