export function canClaimReward(completed:boolean,claimed:boolean):boolean{return completed&&!claimed;}
