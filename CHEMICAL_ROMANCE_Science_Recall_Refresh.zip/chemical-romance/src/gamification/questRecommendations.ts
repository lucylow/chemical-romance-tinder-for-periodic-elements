import type {GamificationState} from "./types";
import {QUEST_CATALOG} from "./questCatalog";
import {questProgress} from "./questEngine";
export function recommendQuests(s:GamificationState,date=new Date(),limit=3) {
 return QUEST_CATALOG.map(q=>({quest:q,progress:questProgress(s,q,date)}))
 .filter(x=>!x.progress.claimed).sort((a,b)=>(b.progress.value/b.quest.target)-(a.progress.value/a.quest.target)).slice(0,limit);
}
