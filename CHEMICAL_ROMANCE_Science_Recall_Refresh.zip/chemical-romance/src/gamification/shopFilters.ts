import type {CosmeticItem,Rarity} from "./types";
export function filterCosmetics(items:CosmeticItem[],opts:{category?:CosmeticItem["category"];rarity?:Rarity;owned?:string[];maxPrice?:number}) {
 return items.filter(x=>(!opts.category||x.category===opts.category)&&(!opts.rarity||x.rarity===opts.rarity)&&(!opts.owned||opts.owned.includes(x.id))&&(opts.maxPrice===undefined||x.price<=opts.maxPrice));
}
