export type Celebration="none"|"tiny"|"level-up"|"badge"|"quest"|"streak";
export function chooseCelebration(input:{leveledUp:boolean;badge:boolean;quest:boolean;streakMilestone:boolean}):Celebration {
 if(input.leveledUp)return "level-up";if(input.badge)return "badge";if(input.quest)return "quest";if(input.streakMilestone)return "streak";return "tiny";
}
