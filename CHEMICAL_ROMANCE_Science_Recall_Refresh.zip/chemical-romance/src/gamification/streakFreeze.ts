import type {GamificationState} from "./types";
import {STREAK_FREEZE_PRICE} from "./constants";
export function buyStreakFreeze(s:GamificationState):GamificationState {
 if(s.wallet.coins<STREAK_FREEZE_PRICE||s.streak.freezes>=2)return s;
 return {...s,wallet:{...s.wallet,coins:s.wallet.coins-STREAK_FREEZE_PRICE,lifetimeSpent:s.wallet.lifetimeSpent+STREAK_FREEZE_PRICE},streak:{...s.streak,freezes:s.streak.freezes+1}};
}
