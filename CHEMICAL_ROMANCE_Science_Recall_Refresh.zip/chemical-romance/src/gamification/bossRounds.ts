export interface BossRound {id:string;name:string;family:string;questions:number;passPercent:number;rewardXp:number;rewardCoins:number;unlockAfter:number;}
export const BOSS_ROUNDS:BossRound[]=[
{id:"alkali-boss",name:"Alkali Metal Energy",family:"Alkali metals",questions:6,passPercent:80,rewardXp:50,rewardCoins:15,unlockAfter:8},
{id:"halogen-boss",name:"Halogen Drama",family:"Halogens",questions:6,passPercent:80,rewardXp:60,rewardCoins:18,unlockAfter:12},
{id:"noble-boss",name:"Noble Gas Standards",family:"Noble gases",questions:7,passPercent:85,rewardXp:75,rewardCoins:22,unlockAfter:18},
{id:"transition-boss",name:"Transition Metal Mixer",family:"Transition metals",questions:8,passPercent:80,rewardXp:90,rewardCoins:28,unlockAfter:30}
];
export function bossPassed(correct:number,total:number,boss:BossRound):boolean{return total>=boss.questions&&correct/Math.max(1,total)*100>=boss.passPercent;}
