export interface TelemetryEvent {name:string;timestamp:string;properties:Record<string,string|number|boolean>;}
export function makeTelemetry(name:string,properties:TelemetryEvent["properties"]={}):TelemetryEvent {
 return {name,timestamp:new Date().toISOString(),properties};
}
