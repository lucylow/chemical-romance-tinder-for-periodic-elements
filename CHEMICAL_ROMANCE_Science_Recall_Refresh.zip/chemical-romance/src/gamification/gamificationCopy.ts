export const GAME_COPY={
 emptyQuests:"Your next little adventure is waiting.",
 emptyBadges:"No badges yet. Every first step counts.",
 emptyActivity:"Your chemistry story starts here.",
 coinShop:"Spend lab coins on looks, not learning advantages.",
 streak:"A gentle reminder: consistency beats cramming."
};
