import type {GameActivity} from "./types";
export function activityCounts(items:GameActivity[]):Record<string,number>{
 return items.reduce((out,x)=>({...out,[x.kind]:(out[x.kind]??0)+x.amount}),{} as Record<string,number>);
}
export function mostFrequentActivity(items:GameActivity[]):string|null {
 const counts=activityCounts(items);return Object.entries(counts).sort((a,b)=>b[1]-a[1])[0]?.[0]??null;
}
