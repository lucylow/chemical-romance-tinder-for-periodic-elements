export interface SeasonalEvent {id:string;title:string;startsAt:string;endsAt:string;description:string;bonusMultiplier:number;}
export const SEASONAL_EVENTS:SeasonalEvent[]=[
{id:"molecule-march",title:"Molecule Match Week",startsAt:"2026-11-09",endsAt:"2026-11-16",description:"Build compounds to earn bonus lab coins.",bonusMultiplier:1.25},
{id:"periodic-party",title:"Periodic Party",startsAt:"2026-12-01",endsAt:"2026-12-08",description:"Discover element families together.",bonusMultiplier:1.2}
];
export function activeSeasonalEvent(date=new Date()):SeasonalEvent|null {
 const key=date.toISOString().slice(0,10);return SEASONAL_EVENTS.find(e=>key>=e.startsAt&&key<=e.endsAt)??null;
}
