import type { Reward } from "./types";
export const REWARDS = {
  discovery: { xp: 8, coins: 2 }, like: { xp: 2, coins: 0 }, match: { xp: 15, coins: 4 },
  quizCorrect: { xp: 12, coins: 2 }, quizWrong: { xp: 1, coins: 0 },
  formula: { xp: 18, coins: 4 }, lesson: { xp: 20, coins: 3 },
  review: { xp: 10, coins: 1 }, daily: { xp: 35, coins: 10 },
  perfectRound: { xp: 25, coins: 6 }, boss: { xp: 60, coins: 20 }
} as const;
export function rewardLabel(reward: Reward): string {
  if (reward.kind === "xp") return `+${reward.amount ?? 0} XP`;
  if (reward.kind === "coins") return `+${reward.amount ?? 0} lab coins`;
  return reward.label;
}
