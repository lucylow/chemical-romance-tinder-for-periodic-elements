import type {GamificationState} from "./types";
export function claimTutorialStep(s:GamificationState,stepId:string,xp=5):GamificationState {
 const key=`tutorial:${stepId}`;if(s.lifetime[key])return s;
 return {...s,totalXp:s.totalXp+xp,lifetime:{...s.lifetime,[key]:1}};
}
