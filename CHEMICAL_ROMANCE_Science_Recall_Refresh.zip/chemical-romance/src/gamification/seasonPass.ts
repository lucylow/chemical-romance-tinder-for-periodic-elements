export interface SeasonTier {tier:number;xpRequired:number;freeReward:string;premiumReward?:string;}
export const SEASON_TIERS:SeasonTier[]=Array.from({length:20},(_,i)=>({tier:i+1,xpRequired:(i+1)*150,freeReward:i%5===4?"Lab coins":"Sticker",premiumReward:i%4===3?"Exclusive card frame":undefined}));
export function seasonTier(xp:number):number{return Math.min(20,Math.floor(Math.max(0,xp)/150));}
export function seasonProgress(xp:number):number{return Math.max(0,Math.min(1,(xp%150)/150));}
