export const ACHIEVEMENT_MILESTONES=[1,5,10,25,50,75,100,118] as const;
export function nextDiscoveryMilestone(discovered:number):number|null{return ACHIEVEMENT_MILESTONES.find(n=>n>discovered)??null;}
