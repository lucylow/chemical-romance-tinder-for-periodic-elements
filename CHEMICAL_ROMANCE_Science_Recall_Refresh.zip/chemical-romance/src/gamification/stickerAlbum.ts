export interface StickerSlot {id:string;label:string;unlockHint:string;}
export const STICKER_ALBUM:StickerSlot[]=[
{id:"heart-atom",label:"Heart Atom",unlockHint:"Discover five elements."},{id:"tiny-flask",label:"Tiny Flask",unlockHint:"Build your first compound."},
{id:"spark-genius",label:"Spark of Genius",unlockHint:"Complete a perfect round."},{id:"noble-star",label:"Noble Star",unlockHint:"Discover all noble gases."},
{id:"period-pride",label:"Period Pride",unlockHint:"Complete a period collection."},{id:"streak-flame",label:"Streak Flame",unlockHint:"Reach a seven-day streak."}
];
