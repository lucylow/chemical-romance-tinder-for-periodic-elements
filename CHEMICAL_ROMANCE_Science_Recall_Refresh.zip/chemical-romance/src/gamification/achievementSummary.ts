import type {GamificationState} from "./types";
export function achievementSummary(s:GamificationState) {
 return {unlocked:s.badges.length,total:18,percent:Math.round(s.badges.length/18*100),recent:[...s.badges].slice(-3).reverse()};
}
