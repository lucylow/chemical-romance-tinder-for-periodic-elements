export const ACHIEVEMENT_RULES = {
 discoverFirst: (n:number)=>n>=1, discoverAll: (n:number)=>n>=118,
 correctRecall: (n:number)=>n>=100, longStreak: (n:number)=>n>=30,
 validChemistry: (n:number)=>n>=50
};
