export interface RewardBurst {label:string;kind:"xp"|"coins"|"badge"|"level";value?:number;}
export function rewardBursts(xp:number,coins:number,badgeCount=0,levelUp=false):RewardBurst[] {
 const out:RewardBurst[]=[];if(xp>0)out.push({label:`+${xp} XP`,kind:"xp",value:xp});
 if(coins>0)out.push({label:`+${coins} coins`,kind:"coins",value:coins});
 if(badgeCount)out.push({label:`${badgeCount} new badge${badgeCount===1?"":"s"}`,kind:"badge",value:badgeCount});
 if(levelUp)out.push({label:"LEVEL UP!",kind:"level"});return out;
}
