export const HINT_COSTS={first:0,second:2,reveal:5} as const;
export function hintPenalty(baseXp:number,hintsUsed:number):number {
 return Math.max(1,Math.floor(baseXp*(hintsUsed===0?1:hintsUsed===1?0.75:0.4)));
}
