export function sanitizeGamificationExport(input:unknown):unknown {
 if(!input||typeof input!=="object")return input;
 const value={...(input as Record<string,unknown>)};
 delete value.email;delete value.displayName;delete value.userId;delete value.deviceId;
 return value;
}
