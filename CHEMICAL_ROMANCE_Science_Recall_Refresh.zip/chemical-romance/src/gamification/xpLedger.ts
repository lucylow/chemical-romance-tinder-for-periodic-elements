import type {GameActivity} from "./types";
export function xpLedger(items:GameActivity[]) {
 return items.map(a=>({id:a.id,date:a.at,kind:a.kind,xp:Number(a.metadata?.xpAwarded??0)})).filter(x=>x.xp>0);
}
