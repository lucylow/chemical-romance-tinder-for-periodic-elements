import type {GamificationState} from "./types";
export function unlockSticker(s:GamificationState,id:string):GamificationState {
 if(s.inventory.includes(id))return s;return {...s,inventory:[...s.inventory,id]};
}
