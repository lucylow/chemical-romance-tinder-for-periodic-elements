import type {CollectionSet} from "./collectionSets";
import {collectionCount} from "./collectionSets";
export function collectionPercent(set:CollectionSet,discovered:number[]):number {
 return Math.round(collectionCount(set,discovered)/Math.max(1,set.atomicNumbers.length)*100);
}
