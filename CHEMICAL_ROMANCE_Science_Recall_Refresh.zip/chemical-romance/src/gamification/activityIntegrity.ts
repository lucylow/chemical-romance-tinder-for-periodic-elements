import type {GameActivity} from "./types";
export function validateActivity(a:GameActivity):boolean {
 return !!a.id&&!!a.kind&&Number.isFinite(a.amount)&&a.amount>0&&!Number.isNaN(Date.parse(a.at));
}
export function dedupeActivities(items:GameActivity[]):GameActivity[] {
 const seen=new Set<string>();return items.filter(x=>{if(seen.has(x.id))return false;seen.add(x.id);return validateActivity(x);});
}
