import React, { useMemo, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Screen } from "../components/Screen";
import { Button } from "../components/Button";
import { AppText } from "../components/Text";
import { useGame } from "../store/GameContext";
import { useGamification } from "../gamification/GamificationContext";
import { createMemoryQuestion } from "../engine/memoryQuestionEngine";
import { colors, radius, spacing, typography } from "../theme/colors";

export function MemoryScreen() {
  const { answer, award } = useGame();
  const { record } = useGamification();
  const [round, setRound] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [revealed, setRevealed] = useState(false);
  const question = useMemo(() => createMemoryQuestion(round), [round]);
  const correct = selected === question.answer;

  const submit = () => {
    if (!selected || revealed) return;
    const isCorrect = selected === question.answer;
    answer(question.id, question.skill, isCorrect);
    if (isCorrect) award(5);
    record(isCorrect ? "quiz_correct" : "quiz_wrong", 1, { atomicNumber: question.id, skill: question.skill });
    setRevealed(true);
  };

  const next = () => {
    setRound((current) => current + 1);
    setSelected(null);
    setRevealed(false);
  };

  return (
    <Screen>
      <Text style={styles.eyebrow}>MEMORY ACADEMY · ACTIVE RECALL</Text>
      <Text style={styles.title}>Remember me?</Text>
      <AppText style={styles.sub}>Six quick recall skills rotate through the table. Your answer is revealed only after you commit.</AppText>

      <View style={styles.card}>
        <View style={styles.cardTop}>
          <Text style={styles.counter}>QUESTION {round + 1}</Text>
          <Text style={styles.skill}>{question.skill === "atomicNumber" ? "ATOMIC NUMBER" : question.skill.toUpperCase()}</Text>
        </View>
        <Text style={styles.prompt}>{question.prompt}</Text>

        {question.choices.map((choice) => {
          const isSelected = selected === choice;
          const showCorrect = revealed && choice === question.answer;
          const showWrong = revealed && isSelected && !correct;
          return (
            <Pressable
              key={choice}
              accessibilityRole="button"
              accessibilityLabel={`Answer: ${choice}`}
              accessibilityState={{ selected: isSelected, disabled: revealed }}
              disabled={revealed}
              onPress={() => setSelected(choice)}
              style={[styles.choice, isSelected && styles.chosen, showCorrect && styles.correct, showWrong && styles.wrong]}
            >
              <Text style={styles.choiceText}>{choice}</Text>
              {showCorrect && <Text style={styles.answerMark}>CORRECT</Text>}
              {showWrong && <Text style={styles.answerMark}>YOUR PICK</Text>}
            </Pressable>
          );
        })}
      </View>

      {!revealed ? (
        <Button title="Check answer" disabled={!selected} onPress={submit} />
      ) : (
        <>
          <AppText accessibilityLiveRegion="polite" style={[styles.feedback, correct ? styles.feedbackCorrect : styles.feedbackWrong]}>
            {correct ? "Correct — +5 study XP." : `Not quite. The recorded answer is ${question.answer}.`}
          </AppText>
          <Button title="Next question" onPress={next} />
        </>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  eyebrow: { fontSize: typography.eyebrow, letterSpacing: 1.8, color: colors.cyan, fontWeight: "900" },
  title: { fontSize: typography.display - 4, fontWeight: "900", color: colors.text, marginTop: 4 },
  sub: { color: colors.muted, marginTop: spacing.sm, marginBottom: spacing.xl, lineHeight: 20 },
  card: { backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.lg, borderWidth: 1, borderColor: colors.border, marginBottom: spacing.md },
  cardTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  counter: { color: colors.pink, fontSize: typography.eyebrow, fontWeight: "900", letterSpacing: 1.4 },
  skill: { color: colors.violet, fontSize: typography.eyebrow, fontWeight: "900", letterSpacing: 1.1 },
  prompt: { fontSize: 22, fontWeight: "800", color: colors.text, marginVertical: spacing.lg, lineHeight: 29 },
  choice: { minHeight: 50, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderRadius: radius.md, backgroundColor: colors.surface2, marginBottom: spacing.sm, borderWidth: 1, borderColor: "transparent", flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: spacing.sm },
  chosen: { borderColor: colors.pink },
  correct: { backgroundColor: "#24483F", borderColor: colors.success },
  wrong: { backgroundColor: "#51283D", borderColor: colors.danger },
  choiceText: { color: colors.text, fontWeight: "700", flex: 1 },
  answerMark: { color: colors.success, fontSize: 9, fontWeight: "900", letterSpacing: 0.8 },
  feedback: { textAlign: "center", marginBottom: spacing.md, fontWeight: "800" },
  feedbackCorrect: { color: colors.success },
  feedbackWrong: { color: colors.warning },
});
