import React, { useEffect, useMemo, useRef, useState } from "react";
import { AccessibilityInfo, Alert, Animated, Platform, StyleSheet, Text, View } from "react-native";
import { Screen } from "../components/Screen";
import { AppText } from "../components/Text";
import { Button } from "../components/Button";
import { ElementCard } from "../components/ElementCard";
import { ELEMENTS } from "../engine/elementEngine";
import { useGame } from "../store/GameContext";
import { useGamification } from "../gamification/GamificationContext";
import { colors, motion } from "../theme/colors";
import { analyseMatch } from "../engine/matchingEngine";

export function DiscoverScreen() {
  const { state, swipe } = useGame();
  const { record } = useGamification();
  const [index, setIndex] = useState(0);
  const [reduceMotion, setReduceMotion] = useState(false);
  const entrance = useRef(new Animated.Value(0)).current;
  const swipeX = useRef(new Animated.Value(0)).current;
  const animating = useRef(false);
  const pool = useMemo(() => ELEMENTS.filter((element) => !state.swiped.includes(element.atomicNumber)), [state.swiped]);
  const current = pool[index % Math.max(pool.length, 1)];

  useEffect(() => {
    let mounted = true;
    AccessibilityInfo.isReduceMotionEnabled().then((enabled) => {
      if (mounted) setReduceMotion(enabled);
    }).catch(() => {});
    const subscription = AccessibilityInfo.addEventListener("reduceMotionChanged", setReduceMotion);
    return () => {
      mounted = false;
      subscription.remove();
    };
  }, []);

  useEffect(() => {
    entrance.stopAnimation();
    swipeX.stopAnimation();
    swipeX.setValue(0);
    animating.current = false;
    if (reduceMotion) {
      entrance.setValue(1);
      return;
    }
    entrance.setValue(0);
    Animated.spring(entrance, {
      toValue: 1,
      damping: motion.springDamping,
      stiffness: motion.springStiffness,
      mass: 0.8,
      useNativeDriver: Platform.OS !== "web",
    }).start();
    return () => entrance.stopAnimation();
  }, [current?.atomicNumber, reduceMotion, entrance, swipeX]);

  const applyDecision = (liked: boolean) => {
    if (!current) return;
    swipe(current.atomicNumber, liked);
    record("element_discovered", 1, { atomicNumber: current.atomicNumber });
    if (liked) record("element_liked", 1, { atomicNumber: current.atomicNumber });
    if (liked) {
      const partner = ELEMENTS.find((element) => element.atomicNumber !== current.atomicNumber && [1, 6, 7, 8, 11, 17].includes(element.atomicNumber));
      if (partner) {
        const match = analyseMatch(current, partner);
        Alert.alert("A little chemistry?", `${current.name} + ${partner.name}\nSocial vibe: ${match.socialScore}%\n${match.relationship}\n${match.explanation}`);
      }
    }
    setIndex(0);
  };

  const decide = (liked: boolean) => {
    if (!current || animating.current) return;
    if (reduceMotion) {
      applyDecision(liked);
      return;
    }
    animating.current = true;
    Animated.timing(swipeX, {
      toValue: liked ? 420 : -420,
      duration: motion.standard,
      useNativeDriver: Platform.OS !== "web",
    }).start(({ finished }) => {
      if (finished) applyDecision(liked);
      animating.current = false;
      swipeX.setValue(0);
    });
  };

  const likeOpacity = swipeX.interpolate({ inputRange: [0, 80, 220], outputRange: [0, 0.65, 1], extrapolate: "clamp" });
  const passOpacity = swipeX.interpolate({ inputRange: [-220, -80, 0], outputRange: [1, 0.65, 0], extrapolate: "clamp" });
  const rotation = swipeX.interpolate({ inputRange: [-420, 0, 420], outputRange: ["-13deg", "0deg", "13deg"], extrapolate: "clamp" });
  const fade = swipeX.interpolate({ inputRange: [-420, -240, 0, 240, 420], outputRange: [0.25, 1, 1, 1, 0.25], extrapolate: "clamp" });

  return (
    <Screen>
      <View style={styles.header}>
        <View>
          <Text style={styles.eyebrow}>THE PERIODIC DATING APP</Text>
          <Text style={styles.title}>Discover <Text style={styles.titleAccent}>♥</Text></Text>
        </View>
        <Text style={styles.count}>{state.swiped.length}/118</Text>
      </View>

      {current ? (
        <>
          <Animated.View style={{ opacity: fade, transform: [{ translateY: entrance.interpolate({ inputRange: [0, 1], outputRange: [16, 0] }) }, { translateX: swipeX }, { rotate: rotation }, { scale: entrance.interpolate({ inputRange: [0, 1], outputRange: [0.98, 1] }) }] }}>
            <ElementCard element={current} />
            <Animated.View pointerEvents="none" style={[styles.stamp, styles.likeStamp, { opacity: likeOpacity }]}><Text style={styles.stampText}>LIKE</Text></Animated.View>
            <Animated.View pointerEvents="none" style={[styles.stamp, styles.passStamp, { opacity: passOpacity }]}><Text style={styles.stampText}>PASS</Text></Animated.View>
          </Animated.View>
          <View style={styles.actions}>
            <Button title="PASS" variant="outline" onPress={() => decide(false)} style={styles.action} />
            <Button title="LIKE  ♥" onPress={() => decide(true)} style={styles.action} />
          </View>
          <AppText style={styles.hint}>Collect element characters. The social vibe is fictional; chemical facts are shown separately.</AppText>
        </>
      ) : (
        <View style={styles.empty}>
          <Text style={styles.big}>✦</Text>
          <Text style={styles.title}>You've met everyone!</Text>
          <AppText>Visit Memory Academy to keep your chemistry knowledge fresh.</AppText>
          <Button title="Start over" variant="outline" onPress={() => Alert.alert("Reset discovery", "Use Progress → Reset game to restart.")} />
        </View>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 18 },
  eyebrow: { fontSize: 10, letterSpacing: 2, color: colors.cyan, fontWeight: "900" },
  title: { fontSize: 30, fontWeight: "900", color: colors.text },
  titleAccent: { color: colors.pink },
  count: { color: colors.pink, fontWeight: "900" },
  stamp: { position: "absolute", top: 26, paddingHorizontal: 16, paddingVertical: 8, borderWidth: 3, borderRadius: 10 },
  likeStamp: { left: 20, borderColor: colors.success, transform: [{ rotate: "-12deg" }] },
  passStamp: { right: 20, borderColor: colors.pink, transform: [{ rotate: "12deg" }] },
  stampText: { color: colors.text, fontSize: 18, fontWeight: "900", letterSpacing: 2 },
  actions: { flexDirection: "row", gap: 12, marginTop: 16 },
  action: { flex: 1 },
  hint: { color: colors.muted, textAlign: "center", fontSize: 11, marginTop: 14 },
  empty: { alignItems: "center", gap: 16, paddingTop: 80 },
  big: { fontSize: 60, color: colors.gold },
});
