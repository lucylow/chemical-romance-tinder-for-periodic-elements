export const ELEMENT_FAMILIES=[
 {id:"alkali metal",label:"The Drama Club",emoji:"🎭",group:1},
 {id:"alkaline earth metal",label:"The Dependable Squad",emoji:"🛡️",group:2},
 {id:"transition metal",label:"The Popular Crowd",emoji:"✨",group:null},
 {id:"halogen",label:"The Attention Seekers",emoji:"💅",group:17},
 {id:"noble gas",label:"The Independent Icons",emoji:"🪩",group:18},
 {id:"lanthanide",label:"The Rare-Earth VIPs",emoji:"💎",group:null},
 {id:"actinide",label:"The Mysterious Powerhouse",emoji:"🌙",group:null},
 {id:"metalloid",label:"The In-Between Artists",emoji:"🎨",group:null},
 {id:"nonmetal",label:"The Creative Intellectuals",emoji:"📚",group:null}
] as const;
