import type {CompoundScenario} from "../types/game";
export const COMPOUNDS:CompoundScenario[]=[
 {id:"water",formula:"H₂O",name:"Water",components:[1,8],ratio:[2,1],bondType:"Polar covalent",
  explanation:"Two hydrogen atoms are covalently bonded to one oxygen atom. The O–H bonds are polar, and the molecule has a bent shape.",
  challenge:"Build the formula: two Hydrogens for every Oxygen."},
 {id:"carbon-dioxide",formula:"CO₂",name:"Carbon dioxide",components:[6,8],ratio:[1,2],bondType:"Covalent",
  explanation:"One carbon atom is bonded to two oxygen atoms. The molecule is linear, with two C=O double bonds in its common Lewis structure.",
  challenge:"Carbon wants two Oxygen dates. What is the formula?"},
 {id:"sodium-chloride",formula:"NaCl",name:"Sodium chloride",components:[11,17],ratio:[1,1],bondType:"Ionic solid",
  explanation:"Sodium commonly forms Na⁺ and chlorine commonly forms Cl⁻. Oppositely charged ions form an extended ionic lattice; NaCl is a formula unit, not a discrete molecule.",
  challenge:"Balance Na⁺ and Cl⁻ in a 1:1 ratio."},
 {id:"ammonia",formula:"NH₃",name:"Ammonia",components:[7,1],ratio:[1,3],bondType:"Polar covalent",
  explanation:"One nitrogen atom forms three N–H covalent bonds with three hydrogen atoms. The molecular shape is trigonal pyramidal.",
  challenge:"Nitrogen needs three Hydrogens in this starter puzzle."},
 {id:"magnesium-oxide",formula:"MgO",name:"Magnesium oxide",components:[12,8],ratio:[1,1],bondType:"Ionic solid",
  explanation:"Magnesium commonly forms Mg²⁺ and oxygen commonly forms O²⁻. The simplest charge-balanced ratio is 1:1.",
  challenge:"Pair Mg²⁺ with O²⁻ to make a neutral formula unit."},
 {id:"potassium-bromide",formula:"KBr",name:"Potassium bromide",components:[19,35],ratio:[1,1],bondType:"Ionic solid",
  explanation:"Potassium commonly forms K⁺ and bromine commonly forms Br⁻. Their simplest charge-balanced formula is KBr.",
  challenge:"One potassium ion balances one bromide ion."},
 {id:"silicon-dioxide",formula:"SiO₂",name:"Silicon dioxide",components:[14,8],ratio:[1,2],bondType:"Network covalent",
  explanation:"Silicon dioxide forms an extended network of Si–O bonds rather than separate small molecules in common solid forms.",
  challenge:"The formula ratio is one Silicon to two Oxygen atoms."}
];
export function getCompoundForPair(a:number,b:number){return COMPOUNDS.find(c=>c.components.includes(a)&&c.components.includes(b));}
export function getCompoundById(id:string){return COMPOUNDS.find(c=>c.id===id);}
