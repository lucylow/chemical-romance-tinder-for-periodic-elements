export const QUESTS=[
 {id:"hello-hydrogen",title:"Your first date",description:"Discover Hydrogen.",target:1,reward:10},
 {id:"the-first-ten",title:"First ten crushes",description:"Discover elements 1–10.",target:10,reward:50},
 {id:"salt-story",title:"A salty situationship",description:"Build the NaCl formula unit in the Lab.",target:1,reward:25},
 {id:"memory-lane",title:"No peeking",description:"Answer five recall questions.",target:5,reward:30},
 {id:"full-period",title:"Period party",description:"Identify five elements from the same period.",target:5,reward:40}
] as const;
