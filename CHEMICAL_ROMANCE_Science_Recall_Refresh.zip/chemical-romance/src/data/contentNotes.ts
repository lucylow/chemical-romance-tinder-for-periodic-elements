/**
 * CONTENT QUALITY CONTRACT
 * 1. Element identity fields (name, symbol, atomic number) are foundational.
 * 2. Family labels are broad learning categories; edge cases need editorial review.
 * 3. Group is null for the f-block rows represented separately in this starter dataset.
 * 4. Personality is fictional and must never be confused with measured chemistry.
 * 5. A curated compound entry is an educational example, not a full reaction database.
 * 6. Missing compound data means "not modelled", never "impossible".
 * 7. Validate every scientific statement against IUPAC / authoritative chemistry sources.
 * 8. The legacy isDataVerified flag is not field-level provenance or a citation.
 * 9. Taglines and signatureFact starter strings are character copy, not verified chemistry facts.
 * 10. Render property claims only from ScientificFact entries with a source, retrieval date, and explicit data status.
 */
export const CONTENT_VERSION="starter-1.0.0";
export const SCIENCE_DISCLAIMER="Game dialogue is fictional. Chemical facts are educational starter content and should be independently verified before formal instruction.";
