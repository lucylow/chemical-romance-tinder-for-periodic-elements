export const DIALOGUE:Record<number,string[]> = {
 1:["I was here first. That's not a personality flaw; it's chronology.","One proton. One iconic origin story."],
 2:["My outer shell is full. I am not emotionally unavailable; I am electronically content.","I float away from awkward conversations."],
 6:["Four covalent bonds? I call that a healthy social circle.","Diamond and graphite are both me. Range."],
 8:["I support aerobic respiration. I also support taking a break.","Please stop confusing oxygen gas with every oxygen-containing compound."],
 11:["I commonly lose one electron to become Na⁺. The group chat has opinions.","Natrium is my historical Latin-derived name. Na is the clue."],
 17:["I commonly gain one electron to become Cl⁻ in ionic compounds.","Sodium and I have a very famous formula-unit situation."]
};
export function dialogueFor(id:number){return DIALOGUE[id]??["Let's check the periodic table before we make assumptions.","My character lore is playful; my chemistry facts are serious."];}
