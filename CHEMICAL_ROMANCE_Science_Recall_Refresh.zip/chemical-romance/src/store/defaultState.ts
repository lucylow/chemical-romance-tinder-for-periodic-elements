import type {PlayerState,ElementProgress,MasterySkill} from "../types/game";
import {initialSkill} from "../engine/reviewEngine";
const skills:MasterySkill[]=["name","symbol","atomicNumber","group","period","family"];
export function newProgress(atomicNumber:number):ElementProgress{
 return {atomicNumber,discovered:false,liked:false,lastSeenAt:null,skills:Object.fromEntries(skills.map(s=>[s,initialSkill()])) as ElementProgress["skills"]};
}
export function createInitialState():PlayerState{return {version:1,xp:0,coins:0,streak:0,lastPlayedDate:null,swiped:[],liked:[],matches:[],progress:{},completedChallenges:[],soundEnabled:true};}
