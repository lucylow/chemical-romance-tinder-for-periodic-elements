import React,{createContext,useContext,useEffect,useMemo,useState} from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import type {PlayerState,MasterySkill} from "../types/game";
import {createInitialState,newProgress} from "./defaultState";
import {reviewSkill} from "../engine/reviewEngine";
import {getElement} from "../engine/elementEngine";
const KEY="@chemical-romance/player-v1";
type GameContextValue={state:PlayerState;loading:boolean;swipe:(id:number,liked:boolean)=>void;answer:(id:number,skill:MasterySkill,correct:boolean)=>void;award:(xp:number)=>void;reset:()=>void;};
const Context=createContext<GameContextValue|null>(null);
export function GameProvider({children}:{children:React.ReactNode}){
 const [state,setState]=useState(createInitialState); const [loading,setLoading]=useState(true);
 useEffect(()=>{AsyncStorage.getItem(KEY).then(raw=>{if(raw){try{setState({...createInitialState(),...JSON.parse(raw)});}catch{setState(createInitialState());}}}).catch(()=>setState(createInitialState())).finally(()=>setLoading(false));},[]);
 useEffect(()=>{if(!loading)AsyncStorage.setItem(KEY,JSON.stringify(state)).catch(()=>{});},[state,loading]);
 const value=useMemo<GameContextValue>(()=>({
  state,loading,
  swipe:(id,liked)=>setState(s=>{
   const element=getElement(id);if(!element||s.swiped.includes(id))return s;
   const p=s.progress[id]||newProgress(id);const progress={...s.progress,[id]:{...p,discovered:true,liked,lastSeenAt:new Date().toISOString()}};
   return {...s,swiped:[...s.swiped,id],liked:liked?[...s.liked,id]:s.liked,progress,xp:s.xp+5};
  }),
  answer:(id,skill,correct)=>setState(s=>{const p=s.progress[id]||newProgress(id);return {...s,xp:s.xp+(correct?10:2),progress:{...s.progress,[id]:{...p,discovered:true,skills:{...p.skills,[skill]:reviewSkill(p.skills[skill],correct)}}}};}),
  award:(xp)=>setState(s=>({...s,xp:s.xp+xp})),
  reset:()=>setState(createInitialState())
 }),[state,loading]);
 return <Context.Provider value={value}>{children}</Context.Provider>;
}
export function useGame(){const value=useContext(Context);if(!value)throw new Error("useGame must be inside GameProvider");return value;}
