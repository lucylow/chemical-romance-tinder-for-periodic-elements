export const colors = {
  bg:"#190D22", surface:"#251532", surface2:"#34204B", card:"#2B1B38",
  pink:"#FF6FAE", pinkSoft:"#FFC4DA", violet:"#A78BFA", cyan:"#54DDF5",
  gold:"#FFD166", text:"#FFF7FC", muted:"#C8B8D0", border:"#4A3658",
  success:"#71E5BC", danger:"#FF718A", white:"#FFFFFF",
  chemistry:"#54DDF5", xp:"#A78BFA", locked:"#796A84", warning:"#FFCC80",
  complete:"#71E5BC", reward:"#FFD166"
};
export const spacing = { xs:4, sm:8, md:12, lg:18, xl:24, xxl:32 };
export const radius = { sm:12, md:18, lg:26, pill:999 };
export const typography = { display:34, heading:28, title:20, body:15, caption:12, eyebrow:10, mono:16 };
export const motion = { quick:140, standard:220, reveal:360, springDamping:17, springStiffness:190 };
export const layout = { contentMaxWidth:560, touchTarget:48, cardInset:18 };
