export interface DailyChallenge {id:string;title:string;description:string;target:number;reward:number;}
export function getDailyChallenge(date=new Date()):DailyChallenge{
 const day=Math.floor(Date.UTC(date.getUTCFullYear(),date.getUTCMonth(),date.getUTCDate())/86400000);
 const pool:DailyChallenge[]=[
 {id:"symbol-sprint",title:"Symbol Sprint",description:"Recall five element symbols.",target:5,reward:25},
 {id:"family-finder",title:"Family Finder",description:"Identify three element families.",target:3,reward:20},
 {id:"atomic-memory",title:"Atomic Memory",description:"Recall five atomic numbers.",target:5,reward:30}
 ];
 return pool[day%pool.length];
}
