export function friendlyError(error:unknown){if(error instanceof Error)return error.message;return "Something went wrong. Your chemistry is still valid; try again.";}
