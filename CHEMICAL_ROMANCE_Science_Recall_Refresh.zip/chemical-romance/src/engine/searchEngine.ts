import type {ElementCharacter} from "../types/game";
export function rankSearch(elements:ElementCharacter[],query:string){
 const q=query.trim().toLowerCase();if(!q)return elements;
 return [...elements].map(e=>({e,score:e.symbol.toLowerCase()===q?0:e.name.toLowerCase()===q?1:String(e.atomicNumber)===q?2:e.name.toLowerCase().startsWith(q)?3:e.name.toLowerCase().includes(q)?4:9}))
 .filter(x=>x.score<9).sort((a,b)=>a.score-b.score).map(x=>x.e);
}
