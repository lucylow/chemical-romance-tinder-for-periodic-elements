import {getElement} from "./elementEngine";
export function lessonForElement(id:number){
 const e=getElement(id);if(!e)return null;
 return {title:`Meet ${e.name}`,objectives:[`Recognize ${e.symbol}`,`Recall atomic number ${e.atomicNumber}`,`Place it in period ${e.period}`,`Identify its family: ${e.family}`],memoryHook:e.memoryHook};
}
