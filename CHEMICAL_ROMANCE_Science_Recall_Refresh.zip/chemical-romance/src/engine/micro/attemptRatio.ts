export function attemptRatio(correct:number,total:number){return total?correct/total:0;}
