export function challengeProgress(done:number,target:number){return Math.min(100,Math.round(done/target*100));}
