export function quizStreak(n:number){return n>=5?`🔥 ${n} in a row`:`${n} correct in a row`; }
