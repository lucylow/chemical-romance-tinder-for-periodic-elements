export function validAtomicNumber(n:number){return Number.isInteger(n)&&n>=1&&n<=118;}
