export function emptyCollection(){return 'Your collection is waiting for its first crush.';}
