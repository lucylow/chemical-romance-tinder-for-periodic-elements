export function blockName(b:string){return `${b.toUpperCase()}-block`;}
