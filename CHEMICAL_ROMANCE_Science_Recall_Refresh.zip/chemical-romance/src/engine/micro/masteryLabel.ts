export function masteryLabel(correct:number,attempts:number){if(attempts<3)return 'Learning';const p=correct/attempts;return p>=.9?'Mastered':p>=.7?'Familiar':'Learning';}
