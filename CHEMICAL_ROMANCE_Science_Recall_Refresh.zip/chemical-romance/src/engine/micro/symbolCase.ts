export function validSymbolCase(s:string){return /^[A-Z][a-z]?$/.test(s);}
