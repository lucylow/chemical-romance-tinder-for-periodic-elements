export function hintMessage(field:string){return `Hint: focus on the ${field} clue.`;}
