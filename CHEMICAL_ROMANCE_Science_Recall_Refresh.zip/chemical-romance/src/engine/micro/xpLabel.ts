export function xpLabel(xp:number){return `${xp.toLocaleString()} XP`;}
