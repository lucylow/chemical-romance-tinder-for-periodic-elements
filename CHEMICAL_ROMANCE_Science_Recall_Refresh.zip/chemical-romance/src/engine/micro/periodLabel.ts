export function periodLabel(p:number){return `Period ${p}`;}
