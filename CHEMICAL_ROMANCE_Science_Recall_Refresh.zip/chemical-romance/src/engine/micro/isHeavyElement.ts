export function isHeavyElement(n:number){return n>=83;}
