export function sortAtomic<T extends {atomicNumber:number}>(items:T[]){return [...items].sort((a,b)=>a.atomicNumber-b.atomicNumber);}
