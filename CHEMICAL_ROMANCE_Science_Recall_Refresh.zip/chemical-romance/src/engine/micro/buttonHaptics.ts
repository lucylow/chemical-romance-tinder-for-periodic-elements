export function hapticForAction(action:string){return action==='like'||action==='correct'?'success':action==='pass'?'light':'medium';}
