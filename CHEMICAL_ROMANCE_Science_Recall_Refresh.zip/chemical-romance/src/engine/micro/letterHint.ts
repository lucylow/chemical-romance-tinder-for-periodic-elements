export function firstLetterHint(value:string){return value.slice(0,1)+'…';}
