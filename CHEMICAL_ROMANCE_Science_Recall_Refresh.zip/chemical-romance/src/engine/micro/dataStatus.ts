export function dataStatus(verified:boolean){return verified?'Starter fact reviewed':'Needs editorial verification';}
