export function matchCount(n:number){return n===1?'1 match':`${n} matches`; }
