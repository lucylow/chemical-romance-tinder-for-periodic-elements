export function familyCount<T extends {family:string}>(items:T[]){return items.reduce<Record<string,number>>((m,e)=>(m[e.family]=(m[e.family]||0)+1,m),{});}
