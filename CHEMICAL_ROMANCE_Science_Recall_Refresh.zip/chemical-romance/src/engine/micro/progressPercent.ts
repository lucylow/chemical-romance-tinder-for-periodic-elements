export function progressPercent(done:number,total:number){return total?Math.round(done/total*100):0;}
