export function defaultPlayerName(){return 'The Matchmaker';}
