export function lessonCompletion(done:number,total:number){return `${done}/${total} lesson objectives complete`; }
