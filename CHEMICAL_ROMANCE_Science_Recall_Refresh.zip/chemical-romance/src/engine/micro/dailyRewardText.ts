export function dailyRewardText(xp:number){return `Claim ${xp} XP for today's challenge.`;}
