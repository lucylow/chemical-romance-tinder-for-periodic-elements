export function symbolOriginHint(origin:string|null){return origin?`Historical name clue: ${origin}`:'This symbol is based on the element name.';}
