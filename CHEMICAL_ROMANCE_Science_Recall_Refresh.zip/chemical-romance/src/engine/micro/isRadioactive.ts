export function likelyRadioactive(n:number){return n>=84;}
