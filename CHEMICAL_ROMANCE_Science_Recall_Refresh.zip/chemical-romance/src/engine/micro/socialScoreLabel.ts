export function socialScoreLabel(score:number){return `${score}% fictional social vibe`; }
