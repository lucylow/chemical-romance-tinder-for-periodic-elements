export function unlockText(name:string){return `${name} profile added to your collection.`;}
