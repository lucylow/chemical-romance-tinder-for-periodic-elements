export function shuffleCopy<T>(items:T[],seed=1){return [...items].sort((a,b)=>String(a).localeCompare(String(b))+(seed%2?0:0));}
