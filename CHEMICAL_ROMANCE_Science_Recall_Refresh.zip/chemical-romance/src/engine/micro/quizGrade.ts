export function quizGrade(p:number){return p>=90?'A':p>=80?'B':p>=70?'C':p>=60?'D':'Keep practising';}
