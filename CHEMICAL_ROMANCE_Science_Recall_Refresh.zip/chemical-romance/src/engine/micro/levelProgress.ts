export function levelProgress(xp:number,level:number){return xp-level*level*100;}
