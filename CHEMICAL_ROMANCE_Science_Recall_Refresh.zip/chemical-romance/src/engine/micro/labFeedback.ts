export function labFeedback(correct:boolean){return correct?'Formula assembled. Read the bonding explanation before moving on.':'Not a curated formula yet. Review the atom ratio and try again.';}
