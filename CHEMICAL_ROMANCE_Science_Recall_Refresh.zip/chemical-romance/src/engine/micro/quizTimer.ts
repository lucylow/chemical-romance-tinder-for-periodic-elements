export function timerRemaining(start:number,limit=60,now=Date.now()){return Math.max(0,limit-Math.floor((now-start)/1000));}
