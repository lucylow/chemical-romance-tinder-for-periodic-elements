export function bondingTag(type:string){return type.toLowerCase().replace(/\s+/g,'-');}
