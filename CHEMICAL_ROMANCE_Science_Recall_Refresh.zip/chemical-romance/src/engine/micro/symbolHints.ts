export function symbolHint(symbol:string){return symbol.length===1?'One-letter symbol.':'Two-letter symbol: capitalize the first letter only.';}
