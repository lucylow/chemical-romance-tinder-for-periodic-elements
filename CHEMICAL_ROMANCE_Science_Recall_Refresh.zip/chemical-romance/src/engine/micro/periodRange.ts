export function periodRange(p:number){return {min:p,max:p};}
