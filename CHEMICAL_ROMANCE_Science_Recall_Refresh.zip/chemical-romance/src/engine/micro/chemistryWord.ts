export function chemistryWord(type:string){return `${type} chemistry`; }
