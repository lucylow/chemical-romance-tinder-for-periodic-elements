export function blockDescription(b:string){return ({s:'s-block',p:'p-block',d:'d-block',f:'f-block'} as Record<string,string>)[b]??'block not assigned';}
