export function blockColor(block:string){return ({s:'#FF8A9D',p:'#78DCC1',d:'#A68BFF',f:'#F3A5C8'} as Record<string,string>)[block]??'#9B7BFF';}
