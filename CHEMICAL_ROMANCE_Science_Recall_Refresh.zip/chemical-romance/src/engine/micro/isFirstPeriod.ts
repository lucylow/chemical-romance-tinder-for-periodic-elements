export function isFirstPeriod(period:number){return period===1;}
