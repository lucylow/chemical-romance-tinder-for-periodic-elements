export function symbolSearch(symbol:string,q:string){return symbol.toLowerCase().startsWith(q.toLowerCase());}
