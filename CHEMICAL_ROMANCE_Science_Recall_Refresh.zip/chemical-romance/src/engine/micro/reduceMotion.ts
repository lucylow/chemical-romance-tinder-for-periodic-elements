export function animationDuration(reduceMotion:boolean){return reduceMotion?0:240;}
