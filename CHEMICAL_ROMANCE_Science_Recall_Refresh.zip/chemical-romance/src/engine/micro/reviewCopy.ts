export function reviewCopy(due:number){return due?`${due} element facts are due for review.`:'Nothing due right now. Keep the streak alive tomorrow.';}
