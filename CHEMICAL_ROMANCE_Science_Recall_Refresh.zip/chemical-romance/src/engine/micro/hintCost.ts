export function hintCost(level:number){return Math.max(1,Math.ceil(level*1.5));}
