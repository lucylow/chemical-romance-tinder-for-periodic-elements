export function coinBalance(n:number){return `${Math.max(0,n)} atoms`; }
