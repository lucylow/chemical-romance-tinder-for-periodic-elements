export function cardCount(n:number){return `${n} profiles`; }
