export const BOND_TYPES=['Ionic','Covalent','Metallic','Network covalent','Coordinate covalent'] as const;
