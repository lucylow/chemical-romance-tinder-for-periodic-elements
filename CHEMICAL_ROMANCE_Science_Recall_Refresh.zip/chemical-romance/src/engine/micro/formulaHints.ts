export function formulaHint(formula:string){return formula.includes('₂')?'A subscript tells you how many atoms of the preceding element are present.':'Check the atom count and charge balance.';}
