export function skillLabel(s:string){return s.replace(/([A-Z])/g,' $1').replace(/^./,c=>c.toUpperCase());}
