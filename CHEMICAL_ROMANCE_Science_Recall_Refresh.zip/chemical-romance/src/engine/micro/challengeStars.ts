export function starsForAccuracy(p:number){return p>=95?3:p>=75?2:p>=50?1:0;}
