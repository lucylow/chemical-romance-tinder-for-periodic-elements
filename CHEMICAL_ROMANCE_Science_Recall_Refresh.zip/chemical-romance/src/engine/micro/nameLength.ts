export function nameLength(name:string){return name.length;}
