export function reviewThanks(correct:boolean){return correct?'Your memory just got stronger.':'A miss is useful information. Review soon.';}
