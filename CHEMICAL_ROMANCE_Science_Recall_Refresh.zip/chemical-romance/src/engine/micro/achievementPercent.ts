export function achievementPercent(unlocked:number,total:number){return total?Math.round(unlocked/total*100):0;}
