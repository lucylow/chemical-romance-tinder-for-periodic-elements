export function profileQuote(line:string){return `“${line}”`; }
