export function recallPrompt(name:string){return `Without peeking: what do you remember about ${name}?`; }
