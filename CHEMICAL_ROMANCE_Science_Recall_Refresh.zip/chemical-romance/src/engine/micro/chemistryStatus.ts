export function chemistryStatus(status:string){return status==='known-scenario'?'A chemistry lesson is available':'Chemistry not modelled for this pair';}
