export function scientificBadge(known:boolean){return known?'Curated chemistry lesson':'Not modelled yet';}
