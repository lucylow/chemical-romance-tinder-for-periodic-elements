export function ordinalGroup(g:number|null){return g===null?'f-block series':`Group ${g}`;}
