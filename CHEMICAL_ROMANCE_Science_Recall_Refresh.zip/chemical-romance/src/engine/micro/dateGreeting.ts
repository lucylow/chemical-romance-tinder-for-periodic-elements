export function dateGreeting(hour=new Date().getHours()){return hour<12?'Good morning, Matchmaker':hour<18?'Good afternoon, Matchmaker':'Good evening, Matchmaker';}
