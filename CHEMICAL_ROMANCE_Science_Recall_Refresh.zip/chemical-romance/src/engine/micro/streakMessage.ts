export function streakMessage(days:number){return days>1?`${days} days of chemistry`:days===1?'Your first day in the lab':'Start a streak today';}
