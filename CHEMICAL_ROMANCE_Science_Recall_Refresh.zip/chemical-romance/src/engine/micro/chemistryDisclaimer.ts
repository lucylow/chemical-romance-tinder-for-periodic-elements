export function chemistryDisclaimer(){return 'Game compatibility is not a measured chemical property.';}
