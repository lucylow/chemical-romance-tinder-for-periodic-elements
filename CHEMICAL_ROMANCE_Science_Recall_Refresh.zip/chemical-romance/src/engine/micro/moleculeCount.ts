export function atomCount(ratios:number[]){return ratios.reduce((a,b)=>a+b,0);}
