import type {ElementCharacter} from '../../types/game';

export function compare(a:ElementCharacter,b:ElementCharacter){return {samePeriod:a.period===b.period,sameGroup:a.group!==null&&a.group===b.group,sameBlock:a.block===b.block,sameFamily:a.family===b.family};}
