export function familyEmoji(f:string){return f.includes('noble')?'🪩':f.includes('halogen')?'💅':f.includes('alkali')?'🎭':'🧪';}
