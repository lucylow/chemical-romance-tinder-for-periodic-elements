export function groupFact(group:number){return group===18?'Noble gases occupy Group 18.':group===17?'Halogens occupy Group 17.':`Explore patterns in Group ${group}.`;}
