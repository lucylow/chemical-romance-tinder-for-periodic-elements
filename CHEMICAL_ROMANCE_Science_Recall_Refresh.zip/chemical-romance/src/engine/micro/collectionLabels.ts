export function collectionLabel(count:number){return count===118?'Full table unlocked':`${count} of 118 element profiles collected`;}
