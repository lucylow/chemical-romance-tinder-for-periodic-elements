export function quizResult(ok:boolean){return ok?'Correct':'Try again';}
