export function periodFact(period:number){return `Period ${period} is row ${period} of the periodic table.`;}
