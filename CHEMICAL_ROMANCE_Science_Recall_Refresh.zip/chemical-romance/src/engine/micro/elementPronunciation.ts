export function pronunciationFallback(name:string){return `Say the element name aloud: ${name}.`;}
