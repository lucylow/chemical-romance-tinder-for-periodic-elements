export function safeAtomicLabel(n:number){return `Atomic number ${n}`;}
