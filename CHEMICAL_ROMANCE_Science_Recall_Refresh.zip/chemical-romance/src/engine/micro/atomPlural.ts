export function atomPlural(n:number){return n===1?'atom':'atoms';}
