export function swipeLabel(liked:boolean){return liked?'Added to your likes':'Passed for now';}
