export type Difficulty="starter"|"standard"|"challenge";
export function difficultyForAccuracy(accuracy:number):Difficulty{return accuracy>=90?"challenge":accuracy>=65?"standard":"starter";}
export function optionCount(difficulty:Difficulty){return difficulty==="starter"?3:difficulty==="standard"?4:6;}
