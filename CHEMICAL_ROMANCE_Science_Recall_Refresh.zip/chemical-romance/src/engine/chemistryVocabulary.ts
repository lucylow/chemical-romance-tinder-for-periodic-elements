export const VOCABULARY=[
 {term:"Atomic number",definition:"The number of protons in an atom's nucleus."},
 {term:"Group",definition:"A vertical column in the periodic table."},
 {term:"Period",definition:"A horizontal row in the periodic table."},
 {term:"Ion",definition:"An atom or group of atoms with a net electric charge."},
 {term:"Ionic bonding",definition:"Electrostatic attraction between oppositely charged ions."},
 {term:"Covalent bonding",definition:"Bonding involving shared electron pairs."},
 {term:"Electronegativity",definition:"A measure of an atom's tendency to attract shared electrons."}
] as const;
