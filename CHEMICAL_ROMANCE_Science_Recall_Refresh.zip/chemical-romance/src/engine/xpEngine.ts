export function xpForAnswer(correct:boolean,hintUsed:boolean){return correct?(hintUsed?6:10):1;}
export function levelFromXp(xp:number){return Math.floor(Math.sqrt(Math.max(0,xp)/100))+1;}
export function xpToNextLevel(xp:number){const level=levelFromXp(xp);return Math.max(0,level*level*100-xp);}
