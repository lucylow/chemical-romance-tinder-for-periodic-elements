export const ONBOARDING=[
 {title:"Meet your elements",body:"Swipe through 118 character profiles inspired by the periodic table."},
 {title:"Separate vibes from science",body:"Social compatibility is playful. Chemical outcomes come from curated chemistry lessons."},
 {title:"Remember the details",body:"Short recall challenges help you learn names, symbols, numbers and families."}
] as const;
