export const STORY_ARCS=[
 {id:"first-spark",title:"The First Spark",chapter:1,unlockAt:0,summary:"Meet the first ten elements and learn their symbols."},
 {id:"family-drama",title:"Family Drama",chapter:2,unlockAt:10,summary:"Explore periodic families and recurring patterns."},
 {id:"bonded-for-life",title:"Bonded for Life",chapter:3,unlockAt:20,summary:"Build a set of curated compounds in the Chemistry Lab."},
 {id:"the-grand-table",title:"The Grand Table",chapter:4,unlockAt:50,summary:"Reconstruct the periodic table from memory."}
] as const;
