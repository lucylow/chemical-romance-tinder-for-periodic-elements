export interface LeaderboardEntry {playerId:string;displayName:string;weeklyXp:number;rank:number;}
export function sortLeaderboard(entries:LeaderboardEntry[]){return [...entries].sort((a,b)=>b.weeklyXp-a.weeklyXp).map((e,i)=>({...e,rank:i+1}));}
