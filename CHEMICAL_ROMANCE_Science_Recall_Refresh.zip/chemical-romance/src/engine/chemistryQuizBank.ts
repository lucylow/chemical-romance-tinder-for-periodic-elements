export const CHEMISTRY_QUESTIONS=[
 {id:"q-group",question:"What is a group in the periodic table?",answer:"A vertical column",choices:["A vertical column","A horizontal row","A single orbital","A type of bond"],topic:"periodic-structure"},
 {id:"q-period",question:"What is a period?",answer:"A horizontal row",choices:["A horizontal row","A vertical column","A family name","An isotope"],topic:"periodic-structure"},
 {id:"q-atomic",question:"What determines an element's atomic number?",answer:"Number of protons",choices:["Number of protons","Number of neutrons","Number of bonds","Number of shells"],topic:"atomic-structure"}
] as const;
