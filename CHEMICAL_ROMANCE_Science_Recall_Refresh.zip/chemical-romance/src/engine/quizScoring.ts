export interface QuizScore {correct:number;total:number;hints:number;elapsedSeconds:number;}
export function scoreQuiz(s:QuizScore){const base=s.correct*10;const accuracy=s.total?Math.round(s.correct/s.total*100):0;const speedBonus=Math.max(0,Math.min(20,Math.floor((60-s.elapsedSeconds)/3)));return {accuracy,xp:Math.max(0,base-s.hints*2+speedBonus)};}
