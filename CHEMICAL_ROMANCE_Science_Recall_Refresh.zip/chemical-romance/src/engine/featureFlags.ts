export const FEATURES={swipeDiscovery:true,localSave:true,starterChemistryLab:true,aiChats:false,multiplayer:false,cloudSync:false,teacherDashboard:false};
