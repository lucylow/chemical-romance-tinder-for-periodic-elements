import raw from "../data/elements.json";
import type {ElementCharacter} from "../types/game";
export const ELEMENTS = raw as ElementCharacter[];
export const ELEMENT_BY_NUMBER = new Map(ELEMENTS.map(e=>[e.atomicNumber,e]));
export const ELEMENT_BY_SYMBOL = new Map(ELEMENTS.map(e=>[e.symbol.toLowerCase(),e]));
export function getElement(n:number){ return ELEMENT_BY_NUMBER.get(n); }
export function searchElements(q:string){
 const s=q.trim().toLowerCase(); if(!s)return ELEMENTS;
 return ELEMENTS.filter(e=>e.name.toLowerCase().includes(s)||e.symbol.toLowerCase()===s||String(e.atomicNumber)===s||e.family.toLowerCase().includes(s));
}
export function getNextUndiscovered(swiped:number[], seed=Date.now()){
 const available=ELEMENTS.filter(e=>!swiped.includes(e.atomicNumber));
 if(!available.length)return null;
 return available[Math.abs(seed)%available.length];
}
export function getFamilyCounts(){
 return ELEMENTS.reduce<Record<string,number>>((a,e)=>{a[e.family]=(a[e.family]||0)+1;return a;},{});
}
