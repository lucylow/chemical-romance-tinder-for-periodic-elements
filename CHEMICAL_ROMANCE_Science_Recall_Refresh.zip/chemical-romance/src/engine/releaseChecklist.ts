export const RELEASE_CHECKLIST=[
 "Verify all 118 identity fields against the current IUPAC periodic table.",
 "Review family and group placement edge cases with a chemistry educator.",
 "Replace generated character hooks with individually edited original writing.",
 "Commission or create licensed character illustrations.",
 "Test swipe gestures on iOS and Android devices.",
 "Add accessibility labels and dynamic type checks.",
 "Add privacy policy, terms, support contact and age rating.",
 "Test local-save migration and offline recovery.",
 "Validate every compound and structure against authoritative references.",
 "Run classroom usability tests before making learning-effectiveness claims."
] as const;
