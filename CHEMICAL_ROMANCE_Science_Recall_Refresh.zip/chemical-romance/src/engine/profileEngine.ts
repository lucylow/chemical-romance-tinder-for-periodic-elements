import type {ElementCharacter} from "../types/game";
export function profileSubtitle(e:ElementCharacter){return `#${e.atomicNumber} · Period ${e.period} · ${e.group?`Group ${e.group}`:"f-block"}`;}
export function profileFacts(e:ElementCharacter){return [{label:"Symbol",value:e.symbol},{label:"Atomic number",value:String(e.atomicNumber)},{label:"Family",value:e.family},{label:"Block",value:e.block.toUpperCase()}];}
