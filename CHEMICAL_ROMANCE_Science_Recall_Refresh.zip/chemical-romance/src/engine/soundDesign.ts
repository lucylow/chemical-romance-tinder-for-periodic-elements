export type SoundCue="like"|"pass"|"match"|"correct"|"incorrect"|"level-up";
export const SOUND_CUE_NOTES:Record<SoundCue,string>={like:"soft heart pop",pass:"gentle whoosh",match:"sparkle chime",correct:"bright two-note chime",incorrect:"soft muted tap","level-up":"ascending celebration"};
