import type {SkillStats} from "../types/game";
const DAY=86400000;
export function initialSkill():SkillStats{return {attempts:0,correct:0,streak:0,ease:2.3,intervalDays:0,dueAt:null};}
export function reviewSkill(previous:SkillStats,correct:boolean,now=new Date()):SkillStats{
 const attempts=previous.attempts+1;
 if(!correct)return {...previous,attempts,streak:0,intervalDays:0,ease:Math.max(1.3,previous.ease-.2),dueAt:new Date(now.getTime()+10*60*1000).toISOString()};
 const streak=previous.streak+1;
 const intervalDays=streak===1?1:streak===2?3:Math.max(4,Math.round(Math.max(1,previous.intervalDays)*previous.ease));
 const ease=Math.min(3.1,previous.ease+.05);
 return {attempts,correct:previous.correct+1,streak,ease,intervalDays,dueAt:new Date(now.getTime()+intervalDays*DAY).toISOString()};
}
export function isDue(skill:SkillStats,now=new Date()){return !!skill.dueAt&&new Date(skill.dueAt).getTime()<=now.getTime();}
export function accuracy(skill:SkillStats){return skill.attempts?Math.round(skill.correct/skill.attempts*100):0;}
