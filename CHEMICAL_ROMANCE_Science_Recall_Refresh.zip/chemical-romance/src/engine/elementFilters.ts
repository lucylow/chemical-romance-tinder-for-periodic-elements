import type {ElementCharacter} from "../types/game";
export function filterByPeriod(items:ElementCharacter[],period:number){return items.filter(e=>e.period===period);}
export function filterByBlock(items:ElementCharacter[],block:string){return items.filter(e=>e.block===block);}
export function filterByGroup(items:ElementCharacter[],group:number){return items.filter(e=>e.group===group);}
