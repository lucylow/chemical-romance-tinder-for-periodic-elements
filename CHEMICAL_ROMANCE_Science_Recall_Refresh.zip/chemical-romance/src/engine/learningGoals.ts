export const LEARNING_GOALS=["Name recognition","Symbol recall","Atomic-number recall","Group identification","Period identification","Family classification","Periodic-table placement"] as const;
export type LearningGoal=typeof LEARNING_GOALS[number];
