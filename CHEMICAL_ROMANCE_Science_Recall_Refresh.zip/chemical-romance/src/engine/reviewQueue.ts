import type {ElementProgress} from "../types/game";
export function dueElements(progress:Record<number,ElementProgress>,now=new Date()){
 return Object.values(progress).filter(p=>Object.values(p.skills).some(s=>s.dueAt&&new Date(s.dueAt)<=now)).sort((a,b)=>a.atomicNumber-b.atomicNumber);
}
