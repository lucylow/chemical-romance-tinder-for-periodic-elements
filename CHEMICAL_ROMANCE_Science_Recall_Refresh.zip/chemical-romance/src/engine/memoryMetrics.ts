import type {ElementProgress} from "../types/game";
import {accuracy} from "./reviewEngine";
export function summarizeProgress(progress:Record<number,ElementProgress>){
 const rows=Object.values(progress);const skills=["name","symbol","atomicNumber","group","period","family"] as const;
 const bySkill=Object.fromEntries(skills.map(k=>{const stats=rows.map(r=>r.skills[k]).filter(s=>s.attempts);const total=stats.reduce((a,s)=>a+s.attempts,0);const correct=stats.reduce((a,s)=>a+s.correct,0);return [k,total?Math.round(correct/total*100):0];}));
 return {discovered:rows.filter(r=>r.discovered).length,liked:rows.filter(r=>r.liked).length,bySkill};
}
