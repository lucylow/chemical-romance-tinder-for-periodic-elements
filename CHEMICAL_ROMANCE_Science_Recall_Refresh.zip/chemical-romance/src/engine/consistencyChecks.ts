import {COMPOUNDS} from "../data/compounds";
import {ELEMENTS} from "./elementEngine";
export function validateCompoundReferences(){
 const ids=new Set(ELEMENTS.map(e=>e.atomicNumber));return COMPOUNDS.flatMap(c=>c.components.filter(id=>!ids.has(id)).map(id=>`${c.id} references missing element ${id}`));
}
