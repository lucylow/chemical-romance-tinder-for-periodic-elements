export function rewardForDiscovery(){return {xp:5,coins:1};}
export function rewardForCorrectRecall(hintUsed:boolean){return {xp:hintUsed?5:10,coins:hintUsed?0:1};}
export function canAfford(balance:number,cost:number){return Number.isFinite(cost)&&cost>=0&&balance>=cost;}
