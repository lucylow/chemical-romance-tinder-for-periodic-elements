import {ELEMENTS} from "./elementEngine";
import type {MasterySkill} from "../types/game";
export interface QuizItem {atomicNumber:number;skill:MasterySkill;prompt:string;answer:string;options:string[];}
export function makeQuizItem(seed:number,skill:MasterySkill):QuizItem{
 const element=ELEMENTS[Math.abs(seed)%ELEMENTS.length];
 const answer=String(element[skill==="name"?"name":skill==="symbol"?"symbol":skill==="atomicNumber"?"atomicNumber":skill==="group"?"group":skill==="period"?"period":"family"]??"Unknown");
 const options=ELEMENTS.filter(e=>e.atomicNumber!==element.atomicNumber).slice(Math.abs(seed)%30,Math.abs(seed)%30+3).map(e=>String(e[skill==="name"?"name":skill==="symbol"?"symbol":skill==="atomicNumber"?"atomicNumber":skill==="group"?"group":skill==="period"?"period":"family"]??"Unknown"));
 return {atomicNumber:element.atomicNumber,skill,prompt:`Identify ${element.symbol}: ${skill}`,answer,options:[answer,...options]};
}
