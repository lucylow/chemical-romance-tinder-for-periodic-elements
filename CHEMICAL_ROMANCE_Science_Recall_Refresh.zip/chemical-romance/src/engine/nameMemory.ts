const historicalSymbols:Record<string,string>={Na:"Natrium",K:"Kalium",Fe:"Ferrum",Au:"Aurum",Ag:"Argentum",Cu:"Cuprum",Pb:"Plumbum",Hg:"Hydrargyrum",W:"Wolfram",Sn:"Stannum",Sb:"Stibium"};
export function symbolOrigin(symbol:string){return historicalSymbols[symbol]??null;}
export function hasTrickySymbol(symbol:string){return symbolOrigin(symbol)!==null;}
