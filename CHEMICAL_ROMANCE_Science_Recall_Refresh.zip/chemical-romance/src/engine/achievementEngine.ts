export interface Achievement {id:string;title:string;description:string;xp:number;unlocked:boolean;}
export function evaluateAchievements(stats:{swiped:number;liked:number;xp:number;correctAnswers:number}):Achievement[]{
 const defs=[["first-date","First Date","Swipe on your first element",10,stats.swiped>=1],["chemistry-crush","Chemistry Crush","Like five element profiles",30,stats.liked>=5],["periodic-party","Periodic Party","Discover 20 elements",50,stats.swiped>=20],["brainy-bond","Brainy Bond","Answer ten questions correctly",40,stats.correctAnswers>=10],["table-tour","Table Tour","Discover all 118 elements",250,stats.swiped>=118]] as const;
 return defs.map(([id,title,description,xp,unlocked])=>({id,title,description,xp,unlocked}));
}
