export interface LabProgress {completed:string[];bestStreak:number;attempts:number;}
export function completeLab(progress:LabProgress,id:string):LabProgress{return {...progress,completed:progress.completed.includes(id)?progress.completed:[...progress.completed,id],bestStreak:Math.max(progress.bestStreak,progress.completed.length+1),attempts:progress.attempts+1};}
