export function seededIndex(seed:number,length:number){if(length<=0)return -1;let x=seed|0;x^=x<<13;x^=x>>>17;x^=x<<5;return Math.abs(x)%length;}
