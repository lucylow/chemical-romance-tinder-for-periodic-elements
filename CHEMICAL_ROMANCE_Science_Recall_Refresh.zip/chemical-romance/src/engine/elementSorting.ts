import type {ElementCharacter} from "../types/game";
export function sortByAtomicNumber(items:ElementCharacter[]){return [...items].sort((a,b)=>a.atomicNumber-b.atomicNumber);}
export function sortByName(items:ElementCharacter[]){return [...items].sort((a,b)=>a.name.localeCompare(b.name));}
