import type {PlayerState} from "../types/game";
export function collectionCompletion(state:PlayerState,total=118){return Math.round(state.liked.length/total*100);}
export function isCollected(state:PlayerState,id:number){return state.liked.includes(id);}
export function recentlyDiscovered(state:PlayerState){return state.swiped.slice(-8).reverse();}
