export type GameEvent={type:"swipe"|"quiz_answer"|"compound_built"|"profile_opened";elementId?:number;correct?:boolean;timestamp:string};
export function createEvent(type:GameEvent["type"],extra:Partial<GameEvent>={}):GameEvent{return {type,timestamp:new Date().toISOString(),...extra};}
