export function ordinal(n:number){const s=["th","st","nd","rd"],v=n%100;return `${n}${s[(v-20)%10]||s[v]||s[0]}`;}
export function shortFamily(value:string){return value.replace("alkaline earth metal","alkaline earth").replace("post-transition metal","post-transition");}
