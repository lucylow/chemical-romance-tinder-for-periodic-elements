export const PATTERN_LESSONS=[
 {id:"atomic-number",title:"Atomic number increases",summary:"Atomic numbers increase by one from one element to the next."},
 {id:"groups",title:"Family resemblance",summary:"Elements in a group often share patterns in valence structure and chemical behaviour."},
 {id:"periods",title:"Rows tell a story",summary:"A period corresponds to filling a principal electron shell, with important nuances for transition elements."},
 {id:"blocks",title:"s, p, d and f blocks",summary:"Block labels describe the subshell being filled in the simplified periodic-table organization."}
] as const;
