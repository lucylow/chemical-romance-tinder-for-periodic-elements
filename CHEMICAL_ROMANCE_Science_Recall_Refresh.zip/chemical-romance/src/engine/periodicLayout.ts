import type {ElementCharacter} from "../types/game";
export interface TableCell {atomicNumber:number;row:number;column:number;isPlaceholder?:boolean;}
export function periodicPosition(e:ElementCharacter):TableCell{
 if(e.block==="f")return {atomicNumber:e.atomicNumber,row:e.period,column:e.atomicNumber<90?3+(e.atomicNumber-57):3+(e.atomicNumber-89)};
 return {atomicNumber:e.atomicNumber,row:e.period,column:e.group??1};
}
export function groupLabel(group:number|null){return group===null?"Inner transition series":`Group ${group}`;}
