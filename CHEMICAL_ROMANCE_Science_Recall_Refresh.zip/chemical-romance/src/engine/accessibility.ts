export function elementAccessibilityLabel(name:string,symbol:string,number:number){return `${name}, symbol ${symbol}, atomic number ${number}`;}
export function swipeHint(direction:"left"|"right"){return direction==="left"?"Pass this element":"Like this element";}
