import {COMPOUNDS} from "../data/compounds";
export interface FormulaCheck {correct:boolean; scenarioId?:string; formula?:string; message:string;}
export function validateFormula(selected:number[]):FormulaCheck {
 const normalized=[...selected].sort((a,b)=>a-b);
 const found=COMPOUNDS.find(c=>{
  const expected=c.components.flatMap((n,i)=>Array(c.ratio[i]).fill(n)).sort((a,b)=>a-b);
  return expected.length===normalized.length&&expected.every((n,i)=>n===normalized[i]);
 });
 return found?{correct:true,scenarioId:found.id,formula:found.formula,message:`${found.formula} — ${found.name}!`}:{correct:false,message:"Not one of the curated starter formulas. Try checking the atom count and ratio."};
}
export function formatFormula(symbols:string[]){return symbols.join(" + ");}
