import type {ElementCharacter} from "../types/game";
export interface MatchAnalysis { socialScore:number; chemistryStatus:"known-scenario"|"not-modelled"; relationship:string; explanation:string; }
const curated = new Set(["1-8","1-17","6-8","7-1","11-17","12-8","19-35","14-8","20-9"]);
const key=(a:number,b:number)=>[a,b].sort((x,y)=>x-y).join("-");
export function analyseMatch(a:ElementCharacter,b:ElementCharacter):MatchAnalysis {
 const sameFamily=a.family===b.family;
 const socialScore=Math.max(25,Math.min(98,58+(sameFamily?12:0)+((a.atomicNumber+b.atomicNumber)%23)));
 const known=curated.has(key(a.atomicNumber,b.atomicNumber));
 return {
  socialScore, chemistryStatus:known?"known-scenario":"not-modelled",
  relationship:sameFamily?"Cosmic besties":known?"Potential chemistry":"It's complicated",
  explanation:known?"A curated learning scenario exists. Open the Lab to see the formula and bonding explanation.":"We have not modelled this pair yet. That does not mean a compound cannot exist."
 };
}
export function isMutualMatch(playerLiked:boolean, characterLiked:boolean){return playerLiked&&characterLiked;}
