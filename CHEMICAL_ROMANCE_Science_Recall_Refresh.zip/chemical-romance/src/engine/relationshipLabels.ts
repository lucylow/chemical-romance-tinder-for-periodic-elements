export type RelationshipLabel="Cosmic besties"|"Potential chemistry"|"It's complicated"|"Not modelled";
export function relationshipLabel(sameFamily:boolean,curated:boolean):RelationshipLabel{return sameFamily?"Cosmic besties":curated?"Potential chemistry":"Not modelled";}
