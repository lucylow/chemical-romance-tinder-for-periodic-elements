import { ELEMENTS } from "./elementEngine";
import { getSourceLinkedScientificFacts } from "./scientificData";
import type { ElementCharacter } from "../types/game";

const BLOCKS = new Set(["s", "p", "d", "f"]);
const ADVANCED_FIELDS = [
  "atomicWeight", "electronConfiguration", "phaseAtRoomTemperature", "density", "meltingPoint",
  "boilingPoint", "electronegativity", "ionizationEnergy", "discovery", "isotopes",
] as const;

export function validateElementDataset(elements: ElementCharacter[] = ELEMENTS) {
  const errors: string[] = [];
  if (elements.length !== 118) errors.push(`Expected 118 entries, received ${elements.length}`);
  if (new Set(elements.map((element) => element.atomicNumber)).size !== elements.length) errors.push("Atomic numbers are not unique");
  if (new Set(elements.map((element) => element.symbol.toLowerCase())).size !== elements.length) errors.push("Element symbols are not unique");
  if (new Set(elements.map((element) => element.name.toLowerCase())).size !== elements.length) errors.push("Element names are not unique");

  elements.forEach((element) => {
    if (!element.name.trim() || !element.symbol.trim()) errors.push(`Missing identity at atomic number ${element.atomicNumber}`);
    if (!Number.isInteger(element.atomicNumber) || element.atomicNumber < 1 || element.atomicNumber > 118) errors.push(`Out-of-range atomic number ${element.atomicNumber}`);
    if (!Number.isInteger(element.period) || element.period < 1 || element.period > 7) errors.push(`Invalid period at atomic number ${element.atomicNumber}`);
    if (element.group !== null && (!Number.isInteger(element.group) || element.group < 1 || element.group > 18)) errors.push(`Invalid group at atomic number ${element.atomicNumber}`);
    if (!BLOCKS.has(element.block)) errors.push(`Invalid block at atomic number ${element.atomicNumber}`);
  });

  return { valid: errors.length === 0, errors };
}

function hasValue(value: unknown): boolean {
  if (value === null || value === undefined || value === "") return false;
  if (Array.isArray(value)) return value.length > 0;
  return true;
}

/** Reports actual starter-data coverage; missing advanced properties are not errors or guesses. */
export function auditElementDataset(elements: ElementCharacter[] = ELEMENTS) {
  const rawRecords = elements as Array<ElementCharacter & Record<string, unknown>>;
  const propertyCoverage = Object.fromEntries(
    ADVANCED_FIELDS.map((field) => [field, rawRecords.filter((record) => hasValue(record[field])).length]),
  ) as Record<(typeof ADVANCED_FIELDS)[number], number>;
  return {
    totalElements: elements.length,
    identityValidation: validateElementDataset(elements),
    uniqueSymbols: new Set(elements.map((element) => element.symbol.toLowerCase())).size,
    uniqueNames: new Set(elements.map((element) => element.name.toLowerCase())).size,
    legacyVerifiedFlagCount: elements.filter((element) => element.isDataVerified).length,
    signatureTaglineDuplicates: elements.filter((element) => element.signatureFact === element.tagline).length,
    emptyRealWorldUsesCount: elements.filter((element) => element.realWorldUses.length === 0).length,
    sourceLinkedFactCount: elements.reduce((total, element) => total + getSourceLinkedScientificFacts(element).length, 0),
    propertyCoverage,
  };
}
