export const FAMILY_DESCRIPTIONS:Record<string,string>={
 "alkali metal":"Group 1 metals (excluding hydrogen in its usual classification); generally highly reactive.",
 "alkaline earth metal":"Group 2 metals, often forming +2 ions.",
 "halogen":"Group 17 elements; many form -1 ions in binary ionic compounds.",
 "noble gas":"Group 18 elements with filled valence shells in the usual introductory model.",
 "transition metal":"d-block elements with varied oxidation states and coordination chemistry.",
 "lanthanide":"The lanthanide series, often discussed as rare-earth elements.",
 "actinide":"The actinide series; many members are radioactive.",
 "metalloid":"Elements with a mixture of metallic and nonmetallic characteristics.",
 "nonmetal":"Elements with predominantly nonmetallic properties.",
 "post-transition metal":"A broad category of p-block metals."
};
