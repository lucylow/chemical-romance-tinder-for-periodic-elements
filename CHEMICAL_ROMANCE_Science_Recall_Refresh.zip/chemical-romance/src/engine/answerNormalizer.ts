export function normalizeAnswer(value:string){return value.trim().toLocaleLowerCase().replace(/\s+/g," ");}
export function answerMatches(input:string,expected:string){return normalizeAnswer(input)===normalizeAnswer(expected);}
