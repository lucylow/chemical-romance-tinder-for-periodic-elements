import type {ElementCharacter} from "../types/game";
export function makeDeck(elements:ElementCharacter[],seed=1){return [...elements].sort((a,b)=>((a.atomicNumber*seed)%127)-((b.atomicNumber*seed)%127));}
