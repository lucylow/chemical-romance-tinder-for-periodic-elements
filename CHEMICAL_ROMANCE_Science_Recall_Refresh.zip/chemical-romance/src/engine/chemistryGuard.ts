export interface ChemistryClaim {formula:string;source:string;confidence:"curated"|"needs-review";}
export function canDisplayAsFact(claim:ChemistryClaim){return claim.confidence==="curated"&&claim.source.trim().length>0;}
export function unavailableChemistryMessage(){return "This pairing is not in the curated lesson database yet. It may have chemistry we have not modelled.";}
