export function updateStreak(previous:number,lastPlayed:string|null,today=new Date()){
 const key=today.toISOString().slice(0,10);if(lastPlayed===key)return previous;
 const yesterday=new Date(today.getTime()-86400000).toISOString().slice(0,10);
 return lastPlayed===yesterday?previous+1:1;
}
