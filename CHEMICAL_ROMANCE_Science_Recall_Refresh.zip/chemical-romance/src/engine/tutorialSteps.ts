export const TUTORIAL_STEPS=[
 {id:"swipe",title:"Swipe a profile",body:"Like or pass to discover your first element."},
 {id:"fact",title:"Read the memory hook",body:"A joke can be a retrieval cue, but check the scientific fact too."},
 {id:"quiz",title:"Prove you remember",body:"Answer without looking to build durable recall."},
 {id:"lab",title:"Build a compound",body:"Use only the curated starter scenarios in the Lab."}
] as const;
