import type {ElementCharacter} from "../types/game";
export interface StoryBeat {title:string;line:string;fact:string;}
export function buildStory(a:ElementCharacter,b:ElementCharacter):StoryBeat[]{
 return [
 {title:"The first message",line:`${a.name}: ${a.tagline}`,fact:`${a.symbol} is element ${a.atomicNumber}.`},
 {title:"The reply",line:`${b.name}: ${b.tagline}`,fact:`${b.symbol} is element ${b.atomicNumber}.`},
 {title:"The chemistry check",line:"The gossip is fictional. The chemistry is checked separately.",fact:`${a.name} belongs to ${a.family}; ${b.name} belongs to ${b.family}.`}
 ];
}
