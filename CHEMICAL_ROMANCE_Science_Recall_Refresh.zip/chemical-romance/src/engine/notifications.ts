export function reviewReminderCopy(count:number){return count===0?"Your element memory is looking fresh.":"A few element crushes are ready for a memory refresh.";}
