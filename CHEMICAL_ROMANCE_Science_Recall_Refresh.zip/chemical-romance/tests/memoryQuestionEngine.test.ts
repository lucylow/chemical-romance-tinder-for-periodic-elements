import { createMemoryQuestion } from "../src/engine/memoryQuestionEngine";

describe("memory question engine", () => {
  test("cycles through name, symbol, atomic number, family, period, and group recall", () => {
    const skills = Array.from({ length: 6 }, (_, round) => createMemoryQuestion(round).skill);
    expect(skills).toEqual(["symbol", "atomicNumber", "name", "family", "period", "group"]);
  });

  test("is deterministic and returns four distinct choices including the answer", () => {
    for (let round = 0; round < 24; round += 1) {
      const first = createMemoryQuestion(round);
      const second = createMemoryQuestion(round);
      expect(first).toEqual(second);
      expect(first.choices).toHaveLength(4);
      expect(new Set(first.choices).size).toBe(4);
      expect(first.choices).toContain(first.answer);
    }
  });

  test("does not ask for an unavailable f-block group number", () => {
    for (let round = 0; round < 36; round += 1) {
      const question = createMemoryQuestion(round);
      if (question.skill === "group") {
        expect(question.element.group).not.toBeNull();
        expect(question.answer).toBe(String(question.element.group));
      }
    }
  });
});
