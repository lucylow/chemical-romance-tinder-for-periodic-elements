import {validateFormula} from "../src/engine/formulaEngine";
import {reviewSkill,initialSkill} from "../src/engine/reviewEngine";
describe("starter formula validation",()=>{
 test("recognizes water atom ratio",()=>expect(validateFormula([1,1,8]).formula).toBe("H₂O"));
 test("recognizes sodium chloride",()=>expect(validateFormula([11,17]).formula).toBe("NaCl"));
 test("rejects an unlisted combination",()=>expect(validateFormula([1,17]).correct).toBe(false));
});
describe("review scheduling",()=>{
 test("incorrect answer schedules quick retry",()=>expect(reviewSkill(initialSkill(),false).intervalDays).toBe(0));
 test("correct answer schedules next day",()=>expect(reviewSkill(initialSkill(),true).intervalDays).toBe(1));
});
