import {levelFromXp,xpRequiredForLevel} from "../src/gamification/leveling";
import {updateStreak} from "../src/gamification/streakEngine";
import {createGamificationState} from "../src/gamification/defaultState";
import {addQuestActivity,claimQuest,ensureQuestProgress} from "../src/gamification/questEngine";
import {QUEST_CATALOG} from "../src/gamification/questCatalog";
import {purchase} from "../src/gamification/economy";
import {COSMETICS} from "../src/gamification/cosmetics";
import {isPerfectRound,accuracyPercent} from "../src/gamification/perfectRound";
import {recordActivity} from "../src/gamification/activityEngine";

describe("CHEMICAL ROMANCE gamification",()=>{
 test("level curve starts at level one and increases",()=>{
  expect(levelFromXp(0).level).toBe(1);
  expect(levelFromXp(xpRequiredForLevel(3)).level).toBe(3);
 });
 test("streak increments once per new day",()=>{
  const s={current:2,best:2,freezes:0,lastActiveDate:"2026-11-07"};
  expect(updateStreak(s,new Date("2026-11-08T12:00:00")).current).toBe(3);
  expect(updateStreak({...s,lastActiveDate:"2026-11-08"},new Date("2026-11-08T18:00:00")).current).toBe(2);
 });
 test("quest progress completes at target",()=>{
  const q=QUEST_CATALOG.find(x=>x.id==="daily_swipe_5")!;
  let s=ensureQuestProgress(createGamificationState(),new Date("2026-11-09T12:00:00"));
  for(let i=0;i<5;i++)s=addQuestActivity(s,"element_discovered",1,new Date("2026-11-09T12:00:00")).state;
  expect(Object.values(s.quests).some(p=>p.questId===q.id&&p.completed)).toBe(true);
 });
 test("quest reward can only be claimed once",()=>{
  const date=new Date("2026-11-09T12:00:00");
  let s=ensureQuestProgress(createGamificationState(),date);
  for(let i=0;i<5;i++)s=addQuestActivity(s,"element_discovered",1,date).state;
  const first=claimQuest(s,"daily_swipe_5",date);
  const second=claimQuest(first.state,"daily_swipe_5",date);
  expect(first.quest?.id).toBe("daily_swipe_5");expect(second.quest).toBeNull();
 });
 test("shop purchase deducts coins and adds inventory",()=>{
  const s=createGamificationState(), item=COSMETICS.find(x=>x.id==="heart-sticker")!;
  const next=purchase(s,item);
  expect(next.inventory).toContain(item.id);expect(next.wallet.coins).toBe(s.wallet.coins-item.price);
  expect(purchase(next,item)).toBe(next);
 });
 test("perfect rounds require every answer correct",()=>{
  expect(isPerfectRound([true,true,true,true,true])).toBe(true);
  expect(isPerfectRound([true,false,true,true,true])).toBe(false);
  expect(accuracyPercent(4,5)).toBe(80);
 });
 test("activity grants bounded rewards and advances lifetime counters",()=>{
  const r=recordActivity(createGamificationState(),"element_discovered",1,undefined,new Date("2026-11-09T12:00:00"));
  expect(r.xpAwarded).toBeGreaterThan(0);expect(r.state.lifetime.element_discovered).toBe(1);
 });
 test("a curated formula can only grant its scenario reward once",()=>{
  const date=new Date("2026-11-09T12:00:00");
  const first=recordActivity(createGamificationState(),"formula_built",1,{formula:"H2O",scenarioId:"water"},date);
  const repeat=recordActivity(first.state,"formula_built",1,{formula:"H2O",scenarioId:"water"},date);
  expect(first.xpAwarded).toBeGreaterThan(0);expect(repeat.state).toBe(first.state);
  expect(repeat.xpAwarded).toBe(0);expect(repeat.coinsAwarded).toBe(0);
 });
 test("activity types without a reward rule do not fall back to discovery rewards",()=>{
  const r=recordActivity(createGamificationState(),"streak_day",1,undefined,new Date("2026-11-09T12:00:00"));
  expect(r.xpAwarded).toBe(0);expect(r.coinsAwarded).toBe(0);
 });
 test("invalid activity amounts do not mutate progress",()=>{
  const state=createGamificationState();
  const r=recordActivity(state,"element_discovered",-1,undefined,new Date("2026-11-09T12:00:00"));
  expect(r.state).toBe(state);expect(r.xpAwarded).toBe(0);
 });
});
