import { ELEMENTS } from "../src/engine/elementEngine";
import { auditElementDataset, validateElementDataset } from "../src/engine/validation";

describe("periodic dataset", () => {
  test("contains 118 unique atomic numbers", () => {
    expect(ELEMENTS).toHaveLength(118);
    expect(new Set(ELEMENTS.map((element) => element.atomicNumber)).size).toBe(118);
  });

  test("validates identity and table structure", () => expect(validateElementDataset().valid).toBe(true));
  test("Hydrogen is atomic number one", () => expect(ELEMENTS[0]).toMatchObject({ name: "Hydrogen", symbol: "H", atomicNumber: 1 }));
  test("Oganesson is atomic number 118", () => expect(ELEMENTS[117]).toMatchObject({ name: "Oganesson", symbol: "Og", atomicNumber: 118 }));

  test("reports missing source-backed properties rather than implying they are verified", () => {
    const audit = auditElementDataset();
    expect(audit.totalElements).toBe(118);
    expect(audit.identityValidation.valid).toBe(true);
    expect(audit.sourceLinkedFactCount).toBe(0);
    expect(audit.propertyCoverage.atomicWeight).toBe(0);
    expect(audit.propertyCoverage.electronConfiguration).toBe(0);
    expect(audit.emptyRealWorldUsesCount).toBe(118);
  });

  test("flags duplicate chemical symbols", () => {
    const invalid = [...ELEMENTS];
    invalid[1] = { ...invalid[1], symbol: invalid[0].symbol };
    expect(validateElementDataset(invalid).errors).toContain("Element symbols are not unique");
  });
});
