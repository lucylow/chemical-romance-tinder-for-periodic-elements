import { ELEMENTS } from "../src/engine/elementEngine";
import { getSourceLinkedScientificFacts } from "../src/engine/scientificData";
import type { ScientificFact } from "../src/types/game";

const sample = ELEMENTS[0];
const sourcedFact: ScientificFact = {
  id: "fixture-property",
  label: "Test property",
  displayValue: "fixture value",
  status: "evaluated",
  source: { name: "Test fixture", url: "https://example.test/reference", retrievedAt: "2026-11-09" },
};

describe("source-backed scientific content", () => {
  test("excludes facts without per-property provenance", () => {
    const element = { ...sample, scientificFacts: [sourcedFact, { ...sourcedFact, id: "unsourced", source: undefined }] };
    expect(getSourceLinkedScientificFacts(element)).toEqual([sourcedFact]);
  });

  test("excludes explicitly unverified facts and malformed source dates", () => {
    const element = {
      ...sample,
      scientificFacts: [
        { ...sourcedFact, id: "unverified", status: "unverified" as const },
        { ...sourcedFact, id: "bad-date", source: { ...sourcedFact.source!, retrievedAt: "recently" } },
      ],
    };
    expect(getSourceLinkedScientificFacts(element)).toEqual([]);
  });
});
