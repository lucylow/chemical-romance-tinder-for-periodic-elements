# Art assets

`src/components/CharacterPortrait.tsx` currently renders a lightweight, original native-view portrait for every element, with family-specific palettes and atomic-number variations. It is the immediate-loading fallback; no remote image is required.

Optional original, licensed portrait overrides may be added under `assets/characters/` using lowercase element names (for example, `hydrogen.webp`). Keep portraits optimized for mobile, preserve transparent edges when used, and retain the native portrait fallback whenever an override is missing. Do not use unlicensed character art.
